const _0x42f8 = [
    'outline-color\x20:\x20invert',
    'color:\x20',
    'change',
    'background-color:',
    'width:\x2022%',
    'overflow\x20:\x20visible',
    'color:\x20#020202',
    'margin-top:\x203px',
    'This\x20Hour',
    'May',
    'float\x20:\x20none',
    'https://http-api.livecoinwatch.com/widgets/coins?sort=cap&order=descending',
    'column-rule-color\x20:\x20currentColor',
    'circle',
    'toLowerCase',
    'height:\x20100%',
    'USD',
    'height:\x2064px',
    'Nov',
    'Today',
    'getMonth',
    'max',
    'coins',
    'none',
    '.png',
    'constructor',
    '#',
    'Jun',
    'stats',
    'getElementsByClassName',
    'width:\x20100%',
    'border-bottom-left-radius\x20:\x200',
    'losers',
    'height:\x2024px',
    'hist',
    'border-radius:\x205px',
    'column-count\x20:\x20auto',
    'innerWidth',
    'push',
    'BZ$',
    'padding-right:',
    '1010676UDKKuK',
    'font-weight\x20:\x20normal',
    'toUpperCase',
    'firstChild',
    'border-width:',
    'success',
    '#d4d4d5',
    'code',
    'border-color:\x20#d4d4d5',
    'text/css',
    'https://lcw.nyc3.cdn.digitaloceanspaces.com/production/currencies/64/',
    'createSVGPoint',
    'border-bottom-style\x20:\x20none',
    'onreadystatechange',
    'https://http-api.livecoinwatch.com/widgets/stats',
    'box-shadow\x20:\x20none',
    'Jul',
    'fill:',
    'border-bottom-width\x20:\x20medium',
    'pointer-events:\x20none',
    '1tMwoIY',
    'font-size:\x2010px',
    'mousemove',
    'date',
    'background-color:\x20transparent',
    '\x22/>',
    'transition-property\x20:\x20none',
    'height:\x2072px',
    'border-bottom-color\x20:\x20inherit',
    'padding-top:\x2025px',
    'forEach',
    'column-width\x20:\x20auto',
    'send',
    'animation-name\x20:\x20none',
    'list-style\x20:\x20none',
    'border-collapse\x20:\x20separate',
    'height:\x2042px',
    'parse',
    'day',
    'clientX',
    'lcw-d-code',
    'display:\x20none',
    'float:\x20right',
    'CHF',
    'font\x20:\x20normal',
    'pointer-events:\x20auto',
    'width:\x2015%',
    'height:\x2060px',
    'white-space:\x20nowrap',
    'border-spacing\x20:\x200',
    'cursor:\x20pointer',
    'capNow',
    'border-radius\x20:\x200',
    'transform-style\x20:\x20flat',
    'border-right\x20:\x200',
    'font-size:\x2018px',
    'border-top-color\x20:\x20inherit',
    'padding:',
    'text-transform\x20:\x20none',
    ';\x20stroke:',
    'top:',
    'height:\x2051px',
    'margin-left:\x2010px',
    'price',
    'padding-left:\x205px',
    'toPrecision',
    'webkitAnimationPlayState',
    'animation:\x20scroll\x20',
    'background-attachment\x20:\x20scroll',
    'livecoinwatch-widget-1',
    'join',
    'animation-duration\x20:\x200',
    'white',
    'find',
    'name',
    '&start=',
    'span',
    '\x20price',
    'inverse',
    'readyState',
    'max-width:\x201680px',
    'display:\x20inline-table',
    'cap',
    'vertical-align\x20:\x20baseline',
    'border-right-width\x20:\x20medium',
    'font-family:\x20\x22Helvetica\x20Neue\x22,\x20Helvetica,\x20Arial,\x20sans-serif',
    '134100EBaMxr',
    'page-break-after\x20:\x20auto',
    'lcw-color-tx',
    '\x20385,',
    'lcw-base',
    '&end=',
    'max-height\x20:\x20none',
    'lcw-d-icon',
    '<svg\x20height=\x22150\x22\x20width=\x22380\x22>',
    'left\x20:\x20auto',
    'type',
    'white-space\x20:\x20normal',
    'Ğ”Ğ¸Ğ½.',
    'TT$',
    '20KLgtOm',
    'color:',
    'This\x20Quarter',
    'px,0,0)\x20}\x20100%\x20{\x20transform:\x20translate3d(-180px,0,0)\x20}\x20}',
    'width:\x2010%',
    'children',
    'livecoinwatch-widget-5',
    '-webkit-mask-image:linear-gradient(to\x20right,\x20rgba(0,0,0,0),\x20rgba(0,0,0,1)\x2010%,rgba(0,0,0,1)\x2090%,rgba(0,0,0,0))',
    'split',
    'border-right-color\x20:\x20inherit',
    'border-left-style\x20:\x20none',
    'border\x20:\x200',
    'startsWith',
    'img',
    'min',
    'border-top-left-radius\x20:\x200',
    'table-layout\x20:\x20auto',
    'height:\x2066px',
    'column-rule-width\x20:\x20none',
    'mouseout',
    'This\x20Week',
    '\x20385,140\x20-5,140\x20-5,',
    'lcw-color-pr',
    'lei',
    'color:\x20#606f89',
    'rate',
    'log',
    'alt',
    'movers',
    'Mar',
    'getElementById',
    '117372ljxPkP',
    'padding-bottom\x20:\x200',
    'clip\x20:\x20auto',
    ';\x20stroke-width:\x202\x22\x20points=\x22',
    'text-align:\x20right',
    'cursor\x20:\x20auto',
    'margin-top:\x200',
    'GET',
    'Oct',
    'caption-side\x20:\x20top',
    '30d',
    'background-clip\x20:\x20border-box',
    '@keyframes\x20scroll\x20{\x200%\x20{\x20transform:\x20translate3d(',
    'padding-top:\x204px',
    'margin-top:',
    'RD$',
    'toFixed',
    'currency',
    'position\x20:\x20static',
    'getHours',
    'lcw-digits',
    'line-height:\x2016px',
    '334619vWxLZY',
    'border-left:\x200',
    '#1f2434',
    'width:\x20280px',
    'backface-visibility\x20:\x20visible',
    '#26da71',
    'background-origin\x20:\x20padding-box',
    'BTC',
    '#ff5a1c',
    '#000000',
    'height:\x20620px',
    'map',
    'height:\x2032px',
    '#00b600',
    'livecoinwatch-widget-2',
    '#d8f1f0',
    'light',
    '\x22\x20d=\x22M25\x203c-.9-.9-1.9-1.6-3.1-2.1-1.2-.5-2.6-.8-4-.8-1.5\x200-2.8.3-4\x20.8-1.2.5-2.3\x201.2-3.2\x202.1-.9.9-1.6\x202-2.1\x203.2-.5\x201.2-.7\x202.5-.7\x203.8\x200\x201.3.2\x202.6.7\x203.8.5\x201.2\x201.1\x202.2\x202\x203l2.8-5.1\x202.8\x202.8\x203.1-7.4-1.3-.6\x201.8-1.3\x201.8-1.3.3\x202.2.3\x202.2-1.3-.6-4\x209.5-3-2.9-1.9\x203.6c.6.5\x201.3.8\x202\x201.1\x201.2.5\x202.6.8\x204\x20.8\x201.5\x200\x202.8-.3\x204-.8\x202.4-1\x204.3-2.9\x205.2-5.3.5-1.2.7-2.5.7-3.8\x200-1.3-.2-2.6-.7-3.8-.7-1.2-1.4-2.2-2.2-3.1z\x22></path></svg>',
    'Feb',
    'height:\x2040px',
    'delta',
    'line-height:\x201em',
    'border-right:\x200',
    'display:\x20inline-block',
    'text-decoration-line\x20:\x20none',
    'background-size\x20:\x20auto\x20auto',
    'display:\x20inline',
    'border-color:',
    'volNow',
    'line-height:\x2024px',
    'left:',
    'right:\x205px',
    'margin-top:\x20-40px',
    'margin-bottom\x20:\x200',
    '&nbsp;-&nbsp;',
    'transparent',
    'lcw-color-bg',
    'floor',
    'column-span\x20:\x201',
    'lcw-d-name',
    '_blank',
    'responseText',
    'height:\x2028px',
    'https://www.livecoinwatch.com/overview',
    'text-indent\x20:\x200',
    'border-left-color\x20:\x20inherit',
    'background-repeat\x20:\x20repeat',
    'getTime',
    'perspective-origin\x20:\x2050%\x2050%',
    's\x20linear\x20infinite',
    'getMinutes',
    'innerHTML',
    'background-image\x20:\x20none',
    '24H\x20VOLUME',
    'height:\x2037px',
    'padding-left\x20:\x200',
    'min-height\x20:\x200',
    'border-width\x20:\x20medium',
    'getAttribute',
    'width:\x20180px',
    'Invalid\x20price\x20response!',
    'open',
    'running',
    'margin-left\x20:\x200',
    'paused',
    'MARKET\x20CAP',
    'width:\x2050%',
    'right\x20:\x20auto',
    'clientY',
    'Dec',
    'target',
    'margin-right:\x2010px',
    'fill:\x20#58c7c5;',
    'box-sizing\x20:\x20content-box',
    'padding:\x203px',
    'border-style:\x20solid',
    'toString',
    'animation-fill-mode\x20:\x20none',
    'line-height:\x2038px',
    'matrixTransform',
    'Invalid\x20top\x20response!',
    'Jan',
    'text-decoration-color\x20:\x20inherit',
    'font-size:\x2012px',
    'slice',
    'overflow-y\x20:\x20visible',
    'animation-play-state\x20:\x20running',
    'height:\x2016px',
    'lcw-coin',
    'undefined',
    'padding-right:\x2010px',
    'visibility:\x20hidden',
    'height\x20:\x20auto',
    'lcw-theme',
    'lcw-marquee-1',
    'abs',
    '',
    'color:\x20#777',
    'color:\x20white',
    'item',
    'Invalid\x20marquee\x20response!',
    'page-break-before\x20:\x20auto',
    'left:\x205px',
    'hour',
    'border-top:\x201px\x20solid\x20#000',
    'padding-top:\x2010px',
    '8121NqPACp',
    'margin-bottom:',
    '#',
    'padding-left:',
    'font-family\x20:\x20inherit',
    'livecoinwatch-widget-6',
    'text-align:\x20left',
    'getDate',
    '24hr',
    'border-color\x20:\x20inherit',
    'page-break-inside\x20:\x20auto',
    'tab-size\x20:\x208',
    'data',
    'http://www.w3.org/2000/svg',
    'outline-style\x20:\x20none',
    'concat',
    'lcw-d-head',
    'src',
    'outline-width\x20:\x20medium',
    '#ffffff',
    'list-style-image\x20:\x20none',
    'top:\x20-5px',
    '?currency=',
    'month',
    'createElementNS',
    'text-align:\x20center',
    'margin-left:',
    'resize',
    'direction\x20:\x20ltr',
    'overflow:\x20hidden',
    'setAttribute',
    'opacity\x20:\x201',
    'content\x20:\x20normal',
    'margin\x20:\x200',
    'week',
    '\x20Price\x20Charts',
    'border-top\x20:\x200',
    'margin:\x205px',
    '#58c7c5',
    'transition-delay\x20:\x200s',
    'style',
    'border-color:\x20#00000042',
    'empty-cells\x20:\x20show',
    'margin-right:',
    'hyphens\x20:\x20none',
    'LOSERS',
    '?coin=',
    'max-width\x20:\x20none',
    '&limit=',
    'border-right-style\x20:\x20none',
    'width',
    'padding-right\x20:\x200',
    'MAX_SAFE_INTEGER',
    'overflow-x\x20:\x20visible',
    'parseInt',
    'bottom\x20:\x20auto',
    'visibility\x20:\x20visible',
    'appendChild',
    'border-width:\x201px',
    'animation-timing-function\x20:\x20ease',
    'replace',
    'text-align\x20:\x20inherit',
    'length',
    'margin-right\x20:\x200',
    '</svg>',
    'animation-direction\x20:\x20normal',
    'lcw-secondary',
    'lcw-marquee-items',
    'createElement',
    'animation-delay\x20:\x200',
    'border-left\x20:\x200',
    'width:\x2025%;\x20text-align:\x20right',
    'B/.',
    'GAINERS',
    'padding-top:\x208px',
    'border-color:\x20transparent',
    'true',
    ';\x20stroke:\x20#58c7c5;\x20stroke-width:\x202\x22\x20points=\x22',
    'outline\x20:\x200',
    'volume',
    'transform\x20:\x20none',
    '102578ybJtgU',
    'head',
    'margin-bottom:\x200',
    'border-top-style\x20:\x20none',
    'lcw-marquee-2',
    'font-size\x20:\x20medium',
    'background-position\x20:\x200\x200',
    '391503jqIsKM',
    'transition-duration\x20:\x200s',
    'text-decoration\x20:\x20none',
    'href',
    'gainers',
    'getScreenCTM',
    '&currency=',
    'position:\x20relative',
    'background-position-x\x20:\x200',
    'border-bottom\x20:\x200',
    'getElementsByTagName',
    'https://http-api.livecoinwatch.com/widgets/coins/movers?range=delta.day&rank=200',
    'column-rule\x20:\x20medium\x20none\x20currentColor',
    'border-color:\x20',
    'background-position-y\x20:\x200',
    'div',
    'addEventListener',
    'border-bottom:\x200',
    'word-spacing\x20:\x20normal',
    'line-height\x20:\x20normal',
    'lcw-period',
    'animation\x20:\x20none',
    'background-color\x20:\x20transparent',
    'lcw-border-w',
    'livecoinwatch-widget-3',
    'list-style-type\x20:\x20disc',
  ];
  function _0x4f2a(_0x4d445a, _0x389c44) {
    _0x4d445a = _0x4d445a - 0x1ad;
    let _0x42f8d5 = _0x42f8[_0x4d445a];
    return _0x42f8d5;
  }
  (function (_0x452034, _0x21bf5d) {
    const _0x4baa11 = _0x4f2a;
    while (!![]) {
      try {
        const _0x655f1 =
          -parseInt(_0x4baa11(0x1cf)) +
          -parseInt(_0x4baa11(0x340)) +
          -parseInt(_0x4baa11(0x2a0)) +
          -parseInt(_0x4baa11(0x2a7)) +
          -parseInt(_0x4baa11(0x1e5)) * -parseInt(_0x4baa11(0x2fe)) +
          -parseInt(_0x4baa11(0x24f)) * parseInt(_0x4baa11(0x1b0)) +
          parseInt(_0x4baa11(0x2ea));
        if (_0x655f1 === _0x21bf5d) break;
        else _0x452034['push'](_0x452034['shift']());
      } catch (_0xc8281a) {
        _0x452034['push'](_0x452034['shift']());
      }
    }
  })(_0x42f8, 0x6ac4a),
    (function () {
      const _0x1ee7c4 = _0x4f2a;
      let _0x3f7434, _0x2fa45c, _0x23257d, _0x5f1dcf, _0x387bdd;
      if (typeof window === _0x1ee7c4(0x23e)) return;
      if (_0x3f7434) clearInterval(_0x3f7434);
      if (_0x2fa45c) clearInterval(_0x2fa45c);
      if (_0x23257d) clearInterval(_0x23257d);
      if (_0x5f1dcf) clearInterval(_0x5f1dcf);
      if (_0x387bdd) clearInterval(_0x387bdd);
      let _0x16d485 = 0xf * 0x3e8,
        _0xc6122a = 0x5 * 0x3c * 0x3e8,
        _0x2155f1 = 0x5265c00,
        _0x48eb4e = {
          d: { l: _0x1ee7c4(0x2d4), t: _0x2155f1 },
          h: { l: _0x1ee7c4(0x2c9), t: _0x2155f1 / 0x18 },
          w: { l: _0x1ee7c4(0x1c4), t: _0x2155f1 * 0x7 },
          m: { l: 'This\x20Month', t: _0x2155f1 * 0x1e },
          q: { l: _0x1ee7c4(0x1b2), t: _0x2155f1 * 0x5a },
          y: { l: 'This\x20Year', t: _0x2155f1 * 0x16d },
        },
        _0x3c3083 = _0x1ee7c4(0x313),
        _0x1329ff = _0x1ee7c4(0x33b),
        _0x5a3f60 = 'margin:\x20auto',
        _0x1d266e = 'position:\x20absolute',
        _0x4343f = _0x1ee7c4(0x2ae),
        _0x10155b = _0x1ee7c4(0x255),
        _0x289187 = _0x1ee7c4(0x1d3),
        _0x3915b6 = 'text-align:\x20center',
        _0x53d79c = '#fb0000',
        _0x4a5eab = _0x1ee7c4(0x1ed),
        _0x197373 = _0x1ee7c4(0x1f2),
        _0x24be26 = _0x1ee7c4(0x1ea),
        _0x5e6894 = _0x10b99f([
          'width:\x20100%',
          'height:\x20100%',
          _0x1ee7c4(0x2e4),
          _0x1ee7c4(0x230),
          _0x1ee7c4(0x255),
          _0x1ee7c4(0x33f),
          _0x1ee7c4(0x274),
          _0x1ee7c4(0x26c),
          _0x1ee7c4(0x22e),
        ]),
        _0x43ec31 = _0x10b99f([_0x5e6894, _0x1ee7c4(0x1ef)]),
        _0x127d00 = _0x10b99f([_0x5e6894, _0x1ee7c4(0x1e8), 'height:\x2060px']),
        _0x24c63e = _0x10b99f([
          _0x5e6894,
          _0x1ee7c4(0x2df),
          _0x1ee7c4(0x33a),
          _0x1ee7c4(0x305),
          'overflow:\x20hidden',
          _0x1ee7c4(0x302),
          'border-width:\x200',
          _0x1ee7c4(0x1b7),
        ]),
        _0x3addd7 = _0x10b99f(['background-color:\x20#1f2434', _0x1ee7c4(0x29a)]),
        _0x38c022 = _0x10b99f(['height:\x2048px', _0x1ee7c4(0x328), 'float:\x20left']),
        _0x3f8418 = _0x10b99f([_0x38c022, _0x1ee7c4(0x2c8)]),
        _0x20cb07 = _0x10b99f([_0x3f8418, _0x1ee7c4(0x21b)]),
        _0x1ace2c = _0x10b99f([_0x20cb07, _0x1ee7c4(0x20f), 'padding-top:\x201px', _0x1ee7c4(0x32a)]),
        _0xf3d3fc = _0x10b99f([_0x3f8418, _0x1ee7c4(0x314), _0x1ee7c4(0x22c), 'margin-left:\x200']),
        _0x12bf07 = _0x10b99f([_0x1ee7c4(0x2df), 'height:\x2052px']),
        _0x2bb301 = _0x10b99f([_0x12bf07, _0x1ee7c4(0x2d2)]),
        _0x1851ba = _0x10b99f([_0x12bf07, _0x1ee7c4(0x30e)]),
        _0xb42409 = _0x10b99f([_0x12bf07, _0x1ee7c4(0x1f1), 'position:\x20relative']),
        _0xdd9c = _0x10b99f([_0x12bf07, _0x1ee7c4(0x327), _0x1ee7c4(0x233)]),
        _0x10da04 = _0x10b99f([
          _0x12bf07,
          _0x1ee7c4(0x327),
          _0x1ee7c4(0x233),
          'border-style:\x20solid',
          _0x1ee7c4(0x289),
          _0x1ee7c4(0x2b8),
          _0x1ee7c4(0x1e6),
          _0x1ee7c4(0x1fb),
        ]),
        _0x2f0dcd = _0x10b99f([_0x12bf07, _0x1ee7c4(0x233)]),
        _0x170c79 = _0x10b99f([_0x12bf07, _0x1ee7c4(0x233), 'background-color:\x20#1b2030']),
        _0x1b34b2 = _0x10b99f([_0x12bf07, _0x1ee7c4(0x205)]),
        _0x5c3294 = _0x10b99f([_0x1b34b2, _0x1ee7c4(0x1f8), _0x1ee7c4(0x24e)]),
        _0x5a4a65 = _0x10b99f([_0x1b34b2, _0x1ee7c4(0x1c1), _0x1ee7c4(0x307)]),
        _0x837592 = _0x10b99f([
          _0x1ee7c4(0x1d5),
          _0x1ee7c4(0x2a2),
          _0x1ee7c4(0x2c7),
          'text-shadow:\x20none',
          _0x1ee7c4(0x1fa),
        ]),
        _0x3df279 = _0x10b99f([_0x1ee7c4(0x246)]),
        _0x3bb012 = _0x10b99f([_0x1ee7c4(0x247)]),
        _0x462ed6 = _0x10b99f([_0x1ee7c4(0x1c8)]),
        _0x70ae7 = _0x10b99f([_0x837592, 'font-size:\x2013px', _0x1ee7c4(0x1fa)]),
        _0x2d1e35 = _0x10b99f([_0x837592, _0x1ee7c4(0x321), _0x1ee7c4(0x1fa)]),
        _0xca64a3 = _0x10b99f(['text-overflow:\x20ellipsis', _0x1ee7c4(0x31a), _0x1ee7c4(0x26c)]),
        _0x2c6234 = _0x10b99f([
          _0x1ee7c4(0x2df),
          'text-align:\x20center',
          _0x1ee7c4(0x24d),
          'line-height:\x200.1em',
          _0x1ee7c4(0x2f2),
        ]),
        _0x46fe34 = _0x10b99f([_0x1ee7c4(0x2df), _0x1ee7c4(0x268), _0x1ee7c4(0x2fd)]),
        _0x4066f8 = _0x10b99f([_0x1ee7c4(0x1fc), _0x1ee7c4(0x227), _0x1ee7c4(0x255)]),
        _0x1e6775 = _0x10b99f([_0x1ee7c4(0x1fc), _0x1ee7c4(0x227), _0x1ee7c4(0x1d3), _0x1ee7c4(0x2fd)]),
        _0x47a1bc = _0x10b99f([_0x1ee7c4(0x2ae), _0x1ee7c4(0x24b), 'top:\x20-5px']),
        _0x17d6f7 = _0x10b99f(['position:\x20relative', _0x1ee7c4(0x204), _0x1ee7c4(0x264)]),
        _0x3b5447 = _0x10b99f([_0x1ee7c4(0x238), _0x1ee7c4(0x317), _0x1ee7c4(0x31c)]),
        _0x3b9afd = _0x10b99f([_0x3b5447]),
        _0x428cee = _0x10b99f(['width:\x20380px', 'height:\x20110px']),
        _0x2bc0a7 = _0x10b99f([
          _0x1ee7c4(0x1ff),
          _0x1ee7c4(0x2ae),
          _0x1ee7c4(0x2d2),
          _0x1ee7c4(0x22f),
          _0x1ee7c4(0x31a),
          _0x1ee7c4(0x26c),
          'will-change:\x20transform',
        ]),
        _0x532795 = _0x10b99f([_0x2bc0a7, _0x1ee7c4(0x2e2)]),
        _0x238dd6 = _0x10b99f([_0x1ee7c4(0x2e2), _0x1ee7c4(0x202)]),
        _0x32bac3 = _0x10b99f([_0x1ee7c4(0x23c), _0x1ee7c4(0x1e4)]),
        _0x50da8c = _0x10b99f([_0x238dd6, _0x1ee7c4(0x31c), _0x1ee7c4(0x1fc), _0x1ee7c4(0x220), _0x1ee7c4(0x2d0)]),
        _0x445f41 = {
          BTC: 'â‚¿',
          ETH: 'Î',
          BGN: 'Ğ»Ğ²',
          NOK: 'kr',
          RUB: 'â‚½',
          AUD: '$',
          BND: '$',
          ARS: '$',
          KHR: 'áŸ›',
          BOB: '$b',
          BBD: '$',
          SAR: 'ï·¼',
          KGS: 'Ğ»Ğ²',
          PAB: _0x1ee7c4(0x297),
          TTD: _0x1ee7c4(0x1af),
          HNL: 'L',
          MZN: 'MT',
          LBP: 'Â£',
          UAH: 'â‚´',
          ILS: 'â‚ª',
          PHP: 'â‚±',
          SGD: '$',
          NAD: '$',
          NZD: '$',
          PLN: 'zÅ‚',
          BRL: 'R$',
          NIO: 'C$',
          QAR: 'ï·¼',
          SRD: '$',
          KZT: 'Ğ»Ğ²',
          BAM: 'KM',
          NGN: 'â‚¦',
          OMR: 'ï·¼',
          LRD: '$',
          MNT: 'â‚®',
          TWD: '$',
          MYR: 'RM',
          LKR: 'â‚¨',
          PEN: 'S/.',
          ISK: 'kr',
          ALL: 'Lek',
          AFN: 'Ø‹',
          BMD: '$',
          EGP: 'Â£',
          BWP: 'P',
          KPW: 'â‚©',
          CRC: 'â‚¡',
          HKD: '$',
          GTQ: 'Q',
          CNY: 'Â¥',
          JMD: 'J$',
          LAK: 'â‚­',
          COP: '$',
          MUR: 'â‚¨',
          ANG: 'Æ’',
          AZN: 'â‚¼',
          CZK: 'KÄ',
          GIP: 'Â£',
          KRW: 'â‚©',
          BSD: '$',
          BYN: 'Br',
          FJD: '$',
          MKD: 'Ğ´ĞµĞ½',
          HRK: 'kn',
          DKK: 'kr',
          AWG: 'Æ’',
          CUP: 'â‚±',
          BZD: _0x1ee7c4(0x2e8),
          CLP: '$',
          GHS: 'Â¢',
          HUF: 'Ft',
          DOP: _0x1ee7c4(0x1de),
          IRR: 'ï·¼',
          EUR: 'â‚¬',
          GYD: '$',
          GBP: 'Â£',
          FKP: 'Â£',
          IDR: 'Rp',
          JPY: 'Â¥',
          USD: '$',
          CHF: _0x1ee7c4(0x315),
          CAD: '$',
          INR: 'â‚¹',
          ZAR: 'R',
          XCD: '$',
          RON: _0x1ee7c4(0x1c7),
          PYG: 'Gs',
          THB: 'à¸¿',
          SVC: '$',
          SCR: 'â‚¨',
          YER: 'ï·¼',
          SOS: 'S',
          SEK: 'kr',
          SBD: '$',
          PKR: 'â‚¨',
          MXN: '$',
          NPR: 'â‚¨',
          VND: 'â‚«',
          UYU: '$U',
          RSD: _0x1ee7c4(0x1ae),
          UZS: 'Ğ»Ğ²',
          TRY: 'â‚º',
          SYP: 'Â£',
          SHP: 'Â£',
        };
      function _0x1babf2() {
        const _0x4177dc = _0x1ee7c4;
        let _0x27ba2d = document['getElementsByClassName'](_0x4177dc(0x1b6));
        for (let _0x320fd6 = 0x0; _0x320fd6 < _0x27ba2d[_0x4177dc(0x28d)]; _0x320fd6++) {
          let _0x56ae87 = _0x27ba2d[_0x4177dc(0x248)](_0x320fd6);
          if (!_0x56ae87) return;
          let _0x312ae1 = (_0x56ae87[_0x4177dc(0x21f)](_0x4177dc(0x344)) || 'USD')['toLowerCase'](),
            _0x4fec93 = (_0x56ae87[_0x4177dc(0x21f)](_0x4177dc(0x243)) || _0x4177dc(0x2d7))[_0x4177dc(0x2cf)](),
            _0xb62f78 = (_0x56ae87[_0x4177dc(0x21f)](_0x4177dc(0x2a4)) || _0x4177dc(0x2d8))[_0x4177dc(0x2cf)](),
            _0x584b01 = _0x56ae87[_0x4177dc(0x21f)](_0x4177dc(0x292)) || '10',
            _0x43dc2b = _0x56ae87['getAttribute'](_0x4177dc(0x342)) || '#000000',
            _0x1b6957 = !![];
          if (_0x4fec93 !== 'coins' && _0x4fec93 !== 'movers') _0x4fec93 = _0x4177dc(0x2d7);
          if (_0xb62f78 !== 'coins' && _0xb62f78 !== _0x4177dc(0x1cc)) _0xb62f78 = _0x4177dc(0x2d8);
          if (_0x584b01 !== '10' && _0x584b01 !== '20' && _0x584b01 !== '30') _0x584b01 = 0xa;
          else _0x584b01 = Number[_0x4177dc(0x285)](_0x584b01);
          let _0x2b0811 = _0x10b99f([_0x24c63e]),
            _0x4582c4 = _0x10b99f([_0x3bb012, _0x4177dc(0x1b1) + _0x43dc2b]),
            _0x1340ab = _0x1b6957 ? _0x462ed6 : _0x3df279,
            _0x37aa55 = _0x1b6957 ? _0x3b9afd : _0x3b5447,
            _0x562b7e = document[_0x4177dc(0x293)]('style');
          (_0x562b7e[_0x4177dc(0x34a)] = _0x4177dc(0x2f3)),
            (_0x562b7e[_0x4177dc(0x218)] = _0x4177dc(0x1db) + _0x584b01 * 0xba + _0x4177dc(0x1b3)),
            document[_0x4177dc(0x2b1)](_0x4177dc(0x2a1))[0x0][_0x4177dc(0x288)](_0x562b7e);
          let _0x1f94aa = _0x58b7e4(_0x4177dc(0x2b6), _0xb42409),
            _0x106a99 = _0x58b7e4(_0x4177dc(0x2b6), _0xb42409),
            _0x21d14e = [];
          (_0x56ae87[_0x4177dc(0x218)] = ''),
            _0x56ae87[_0x4177dc(0x26d)](_0x4177dc(0x277), _0x2b0811),
            _0x532b1f(_0x56ae87, [_0x1f94aa, _0x106a99]),
            window[_0x4177dc(0x2b7)](_0x4177dc(0x26a), function () {
              const _0x2949a3 = _0x4177dc;
              (_0x56ae87[_0x2949a3(0x277)][_0x2949a3(0x281)] = window[_0x2949a3(0x2e6)]),
                _0x21d14e[_0x2949a3(0x308)](function (_0x1cb1cb) {
                  const _0x46d6bd = _0x2949a3;
                  _0x1cb1cb['style'][_0x46d6bd(0x32c)] === _0x46d6bd(0x223) &&
                    ((_0x1cb1cb[_0x46d6bd(0x277)][_0x46d6bd(0x32c)] = _0x46d6bd(0x225)),
                    setTimeout(function () {
                      const _0x23f87b = _0x46d6bd;
                      _0x1cb1cb['style'][_0x23f87b(0x32c)] = _0x23f87b(0x223);
                    }, 0xc8));
                });
            }),
            _0x56ae87[_0x4177dc(0x2b7)]('mouseover', function (_0x29cf32) {
              const _0x257cf4 = _0x4177dc;
              _0x21d14e[_0x257cf4(0x308)](function (_0x32cf27) {
                const _0x339af1 = _0x257cf4;
                if (_0x32cf27[_0x339af1(0x277)][_0x339af1(0x32c)] === _0x339af1(0x223))
                  _0x32cf27['style'][_0x339af1(0x32c)] = _0x339af1(0x225);
              });
            }),
            _0x56ae87['addEventListener'](_0x4177dc(0x1c3), function (_0x24ba23) {
              const _0x38f787 = _0x4177dc;
              _0x21d14e[_0x38f787(0x308)](function (_0x6564af) {
                const _0x1452bb = _0x38f787;
                if (_0x6564af[_0x1452bb(0x277)][_0x1452bb(0x32c)] === _0x1452bb(0x225))
                  _0x6564af['style'][_0x1452bb(0x32c)] = _0x1452bb(0x223);
              });
            });
          if (_0x4fec93 !== 'none')
            for (let _0x57afdb = 0x0; _0x57afdb < _0x584b01; _0x57afdb++) {
              let _0x289e1e = (_0x584b01 / 0xa) * 0x1e,
                _0x33c8b6 = _0x58b7e4(_0x4177dc(0x2b6), [
                  _0x2bc0a7,
                  _0x1d266e,
                  _0xa58018(-0xb4),
                  _0x384a67(_0x289e1e),
                  _0xd23550(_0x57afdb * 0x3),
                ]),
                _0x26bd9c = _0x58b7e4('a', [_0x50da8c]),
                _0x3e8436 = _0x58b7e4(_0x4177dc(0x2b6), [_0x238dd6, _0x1329ff, _0x4177dc(0x2fd)]),
                _0x25ddbb = _0x58b7e4(_0x4177dc(0x336), [_0x837592, _0x4582c4, _0x4343f, _0x3ab5cd(0xc), _0xa58018(0x5)]),
                _0x5f3c0d = _0x58b7e4(_0x4177dc(0x336), [_0x70ae7, _0x4582c4, _0x4343f, _0x3ab5cd(0xa), _0xa58018(0xa)]),
                _0x1c26fa = _0x58b7e4('img', [_0x1ace2c, _0x4177dc(0x2e2), _0x5a4d16(0x9), _0x4177dc(0x2fd)]);
              _0x532b1f(_0x3e8436, [_0x25ddbb, _0x5f3c0d]),
                _0x532b1f(_0x26bd9c, [_0x1c26fa, _0x3e8436]),
                _0x532b1f(_0x33c8b6, _0x26bd9c),
                _0x532b1f(_0x1f94aa, _0x33c8b6),
                _0x21d14e[_0x4177dc(0x2e7)](_0x33c8b6);
            }
          if (_0xb62f78 !== _0x4177dc(0x2d8))
            for (let _0x3f2f22 = 0x0; _0x3f2f22 < _0x584b01; _0x3f2f22++) {
              let _0x2283b7 = (_0x584b01 / 0xa) * 0x19,
                _0x4f0d54 = _0x58b7e4('div', [
                  _0x532795,
                  _0x1d266e,
                  _0xa58018(-0xb4),
                  _0x384a67(_0x2283b7),
                  _0xd23550(_0x3f2f22 * 2.5),
                ]),
                _0xe51f22 = _0x58b7e4('a', [_0x50da8c]),
                _0x4a5ab2 = _0x58b7e4('div', [_0x238dd6, _0x1329ff, _0x4177dc(0x2fd)]),
                _0x2ae1bc = _0x58b7e4('span', [_0x70ae7, _0x4582c4, _0x4343f, _0xa58018(0x5)]),
                _0x13eb17 = _0x58b7e4(_0x4177dc(0x336), [_0x70ae7, _0x4582c4, _0x4343f, _0xa58018(0xa)]),
                _0xf518c6 = _0x58b7e4('span', [_0x70ae7, _0x4582c4, _0x4177dc(0x2fd)]);
              _0x532b1f(_0xe51f22, _0xf518c6),
                _0x532b1f(_0x4a5ab2, [_0x2ae1bc, _0x13eb17]),
                _0x532b1f(_0xe51f22, _0x4a5ab2),
                _0x532b1f(_0x4f0d54, _0xe51f22),
                _0x532b1f(_0x106a99, _0x4f0d54),
                _0x21d14e[_0x4177dc(0x2e7)](_0x4f0d54);
            }
          function _0x3ad0ac(_0x450ae1) {
            let _0x1b8cb0 = _0x4f06d1(_0x584b01, _0x312ae1);
            _0x3c4517(_0x1b8cb0, function (_0xf5cf33) {
              const _0x504d2f = _0x4f2a;
              let _0x126444 = _0xf5cf33[_0x504d2f(0x25b)];
              if (!_0x126444) return console[_0x504d2f(0x1ca)](_0x504d2f(0x249), _0x1b8cb0);
              let _0x77a58a = _0x450ae1 ? _0x1f94aa : _0x106a99;
              for (let _0x49b2fe = 0x0; _0x49b2fe < _0x584b01; _0x49b2fe++) {
                let _0x59ad67 = _0x77a58a['children'][_0x49b2fe],
                  _0xd67f04 = _0x59ad67['children'][0x0][_0x504d2f(0x1b5)][0x1][_0x504d2f(0x1b5)][0x0],
                  _0x93f825 = _0x59ad67[_0x504d2f(0x1b5)][0x0][_0x504d2f(0x1b5)][0x1]['children'][0x1];
                if (_0x450ae1) {
                  let _0x2fc0a0 = _0x59ad67['children'][0x0][_0x504d2f(0x1b5)][0x0];
                  (_0x2fc0a0[_0x504d2f(0x260)] = _0x4daa20(_0x126444[_0x49b2fe][_0x504d2f(0x2f1)])),
                    (_0x2fc0a0[_0x504d2f(0x1cb)] = _0x126444[_0x49b2fe][_0x504d2f(0x334)] + _0x504d2f(0x337));
                } else {
                  let _0xe5e5d3 = _0x59ad67['children'][0x0][_0x504d2f(0x1b5)][0x0];
                  _0xe5e5d3['innerHTML'] = _0x540c9a(_0x126444[_0x49b2fe]['code']);
                }
                (_0x59ad67[_0x504d2f(0x1b5)][0x0][_0x504d2f(0x2aa)] = _0x518176(
                  _0x126444[_0x49b2fe][_0x504d2f(0x334)],
                  _0x126444[_0x49b2fe][_0x504d2f(0x2f1)],
                )),
                  (_0x59ad67[_0x504d2f(0x1b5)][0x0][_0x504d2f(0x22b)] = _0x504d2f(0x20d)),
                  (_0xd67f04[_0x504d2f(0x218)] = _0x482f9f(_0x126444[_0x49b2fe][_0x504d2f(0x329)], _0x312ae1)),
                  _0x2d4778(_0x93f825, _0x126444[_0x49b2fe][_0x504d2f(0x1f9)][_0x504d2f(0x310)], _0x1b6957);
              }
            });
          }
          function _0x617491(_0x149aef) {
            let _0x779491 = _0x1c6bfb(_0x584b01, _0x312ae1);
            _0x3c4517(_0x779491, function (_0x3d22ba) {
              const _0x272b6 = _0x4f2a;
              if (!_0x3d22ba['gainers'] || !_0x3d22ba[_0x272b6(0x2e1)])
                return console[_0x272b6(0x1ca)](_0x272b6(0x249), _0x779491);
              let _0x5dd3ee = _0x3d22ba[_0x272b6(0x2ab)]
                  [_0x272b6(0x239)](0x0, _0x584b01 / 0x2)
                  [_0x272b6(0x25e)](_0x3d22ba[_0x272b6(0x2e1)]['slice'](0x0, _0x584b01 / 0x2)),
                _0x16baf4 = _0x149aef ? _0x1f94aa : _0x106a99;
              for (let _0x57ed07 = 0x0; _0x57ed07 < _0x584b01; _0x57ed07++) {
                let _0x150b90 = _0x16baf4[_0x272b6(0x1b5)][_0x57ed07],
                  _0x26e3de = _0x150b90[_0x272b6(0x1b5)][0x0][_0x272b6(0x1b5)][0x1]['children'][0x0],
                  _0x47f2dc = _0x150b90['children'][0x0]['children'][0x1][_0x272b6(0x1b5)][0x1];
                if (_0x149aef) {
                  let _0x50a213 = _0x150b90[_0x272b6(0x1b5)][0x0][_0x272b6(0x1b5)][0x0];
                  (_0x50a213[_0x272b6(0x260)] =
                    _0x5dd3ee[_0x272b6(0x28d)] <= _0x584b01 ? _0x4daa20(_0x5dd3ee[_0x57ed07][_0x272b6(0x2f1)]) : ''),
                    (_0x50a213['alt'] = _0x5dd3ee[_0x57ed07][_0x272b6(0x334)] + '\x20price');
                } else {
                  let _0xa36ffb = _0x150b90[_0x272b6(0x1b5)][0x0][_0x272b6(0x1b5)][0x0];
                  _0xa36ffb[_0x272b6(0x218)] =
                    _0x5dd3ee[_0x272b6(0x28d)] <= _0x584b01 ? _0x540c9a(_0x5dd3ee[_0x57ed07][_0x272b6(0x2f1)]) : '';
                }
                _0x5dd3ee[_0x272b6(0x28d)] <= _0x584b01
                  ? ((_0x150b90['children'][0x0][_0x272b6(0x2aa)] = _0x518176(
                      _0x5dd3ee[_0x57ed07][_0x272b6(0x334)],
                      _0x5dd3ee[_0x57ed07][_0x272b6(0x2f1)],
                    )),
                    (_0x150b90['children'][0x0][_0x272b6(0x22b)] = _0x272b6(0x20d)),
                    (_0x26e3de[_0x272b6(0x218)] = _0x482f9f(_0x5dd3ee[_0x57ed07][_0x272b6(0x329)], _0x312ae1)),
                    _0x2d4778(_0x47f2dc, _0x5dd3ee[_0x57ed07][_0x272b6(0x1f9)][_0x272b6(0x310)], _0x1b6957))
                  : ((_0x26e3de[_0x272b6(0x218)] = ''), (_0x47f2dc['innerHTML'] = ''));
              }
            });
          }
          function _0x4bae4c() {
            const _0x2f25d6 = _0x4177dc;
            if (_0x4fec93 === _0x2f25d6(0x2d7)) _0x3ad0ac(!![]);
            else {
              if (_0x4fec93 === _0x2f25d6(0x1cc)) _0x617491(!![]);
            }
            if (_0xb62f78 === _0x2f25d6(0x2d7)) _0x3ad0ac(![]);
            else {
              if (_0xb62f78 === _0x2f25d6(0x1cc)) _0x617491(![]);
            }
          }
          _0x4bae4c(), (_0x5f1dcf = setInterval(_0x4bae4c, _0x16d485));
        }
      }
      function _0x230020() {
        const _0x229185 = _0x1ee7c4;
        let _0x298791 = document[_0x229185(0x1ce)]('livecoinwatch-widget-4');
        if (!_0x298791) return;
        let _0x562a80 = (_0x298791[_0x229185(0x21f)](_0x229185(0x344)) || _0x229185(0x2d1))[_0x229185(0x2cf)](),
          _0x12e96b = (_0x298791[_0x229185(0x21f)](_0x229185(0x242)) || _0x229185(0x1f5))[_0x229185(0x2cf)]() === 'dark',
          _0xd7926e = (_0x298791[_0x229185(0x21f)]('lcw-d-head') || 'false')[_0x229185(0x2cf)]() === _0x229185(0x29b),
          _0x77717a = (_0x298791['getAttribute'](_0x229185(0x20c)) || _0x229185(0x29b))[_0x229185(0x2cf)]() === 'true',
          _0x2101af =
            (_0x298791[_0x229185(0x21f)](_0x229185(0x312)) || _0x229185(0x29b))[_0x229185(0x2cf)]() === _0x229185(0x29b),
          _0x3e1dc9 = (_0x298791[_0x229185(0x21f)](_0x229185(0x347)) || 'true')[_0x229185(0x2cf)]() === 'true';
        if (!_0x2101af && !_0x3e1dc9) _0x77717a = !![];
        let _0x1624f2 = '',
          _0x1beaa5 = _0x43ec31 + (_0x12e96b ? ';' + _0x3addd7 : ''),
          _0xb85813 = _0x12e96b ? _0x3bb012 : '',
          _0xed08c3 = _0x12e96b ? _0x462ed6 : _0x3df279,
          _0x2529bc = _0x12e96b ? _0x3b9afd : _0x3b5447,
          _0x14c111 = _0x58b7e4(_0x229185(0x2b6), [_0x5c3294, _0x5a4d16(0x0)], _0x22c78e(_0x12e96b)),
          _0x414652 = _0x58b7e4('div', [_0x1851ba, _0x229185(0x23c), _0x2cd0c5(0xf)]),
          _0x593bba = _0x58b7e4('div', [_0x1851ba, _0x229185(0x23c), _0x2cd0c5(0x8)]),
          _0xed140c = _0x58b7e4(_0x229185(0x2b6), ''),
          _0x2f7f91 = _0x58b7e4(_0x229185(0x2b6), ''),
          _0x3cb652 = _0x58b7e4('p', [
            _0x2c6234,
            'border-color:\x20' + (_0x12e96b ? _0x229185(0x208) : _0x229185(0x2f0)),
          ]),
          _0x796db = _0x58b7e4('p', [_0x2c6234, _0x229185(0x2b4) + (_0x12e96b ? _0x229185(0x208) : '#d4d4d5')]),
          _0x255b4b = _0x58b7e4(_0x229185(0x2b6), _0x2cd0c5(-0xa)),
          _0x2e3160 = _0x58b7e4(_0x229185(0x2b6), _0x12e96b ? _0x2cd0c5(-0x2) : _0x2cd0c5(-0xa)),
          _0x9d726b = _0x58b7e4(
            'p',
            [
              _0x70ae7,
              _0x3df279,
              _0xed08c3,
              _0x5a3f60,
              _0x5a4d16(0x3),
              _0x3c3223(0x55),
              _0x57c93b(_0x12e96b ? '#1f2434' : 'white'),
            ],
            _0x229185(0x298),
          ),
          _0x543159 = _0x58b7e4(
            'p',
            [
              _0x70ae7,
              _0x3df279,
              _0xed08c3,
              _0x5a3f60,
              _0x5a4d16(0x3),
              _0x3c3223(0x55),
              _0x57c93b(_0x12e96b ? _0x229185(0x1e7) : _0x229185(0x332)),
            ],
            _0x229185(0x27c),
          );
        (_0x298791[_0x229185(0x218)] = ''),
          _0x298791['setAttribute'](_0x229185(0x277), _0x1beaa5),
          _0x532b1f(_0x3cb652, _0x255b4b),
          _0x532b1f(_0x796db, _0x2e3160),
          _0x532b1f(_0x255b4b, _0x9d726b),
          _0x532b1f(_0x2e3160, _0x543159),
          _0x532b1f(_0x414652, _0x3cb652),
          _0x532b1f(_0x593bba, _0x796db),
          _0x532b1f(_0x298791, [_0x14c111, _0x414652, _0xed140c, _0x593bba, _0x2f7f91]),
          (function _0x54e0e8() {
            _0x3c4517(_0x1624f2, function (_0x54ceba) {
              const _0x274d1e = _0x4f2a;
              setTimeout(_0x54e0e8, _0x16d485);
              if (!_0x54ceba) return console['log']('Invalid\x20top\x20response!', topUrl);
              (_0xed140c[_0x274d1e(0x218)] = ''),
                (_0x2f7f91[_0x274d1e(0x218)] = ''),
                (_0x54ceba = _0x54ceba[_0x274d1e(0x2ab)][_0x274d1e(0x25e)](_0x54ceba[_0x274d1e(0x2e1)])),
                _0x54ceba['forEach'](function (_0x3c9231, _0x2026ae) {
                  const _0x1a0441 = _0x274d1e;
                  let _0xc86419 = _0x12e96b
                      ? _0x2026ae % 0x2
                        ? _0x2f0dcd
                        : _0x170c79
                      : _0x2026ae % 0x5
                      ? _0x10da04
                      : _0xdd9c,
                    _0x3b4685 = _0x58b7e4(_0x1a0441(0x2b6), _0xc86419),
                    _0x38b78d = _0x58b7e4(_0x1a0441(0x2b6), _0x1a0441(0x1b4)),
                    _0x1e4e6e = _0x58b7e4('img', [_0x1ace2c, _0x5a4d16(0x8)]),
                    _0x4b8fec = _0x58b7e4('div', [
                      _0x1329ff,
                      _0x3899bc(0xa),
                      _0x4343f,
                      !_0x77717a || !_0x2101af ? _0x3ab5cd(0x5) : '',
                    ]),
                    _0x33bdec = _0x58b7e4(
                      _0x1a0441(0x2b6),
                      [_0x837592, _0xb85813, _0xca64a3, 'width:\x20140px'],
                      _0x77717a ? _0x3c9231[_0x1a0441(0x334)] : _0x540c9a(_0x3c9231[_0x1a0441(0x2f1)]),
                    ),
                    _0x55c857 = _0x58b7e4('p', [_0x70ae7, _0xed08c3], _0x540c9a(_0x3c9231['code'])),
                    _0x5d1732 = _0x58b7e4('div', [_0x1329ff, _0x3899bc(0xa), _0x1a0441(0x296)]),
                    _0x386479 = _0x58b7e4(
                      'p',
                      [_0x837592, _0xb85813, _0x4343f, _0x3ab5cd(0x5)],
                      _0x482f9f(_0x3c9231['price'], _0x562a80),
                    ),
                    _0x2df8c0 = _0x58b7e4(_0x1a0441(0x2b6), [_0x1329ff, _0x3899bc(0x5), _0x1a0441(0x318)]),
                    _0x16457e = _0x58b7e4('p', [_0x70ae7, _0xb85813, _0x32bac3, _0x4343f, _0x3ab5cd(0x4)]);
                  if (_0x3e1dc9) _0x1e4e6e[_0x1a0441(0x260)] = _0x4daa20(_0x3c9231[_0x1a0441(0x2f1)]);
                  if (_0x77717a || _0x2101af) _0x532b1f(_0x4b8fec, _0x33bdec);
                  if (_0x77717a && _0x2101af) _0x532b1f(_0x4b8fec, _0x55c857);
                  _0x532b1f(_0x38b78d, _0x1e4e6e),
                    _0x532b1f(_0x5d1732, _0x386479),
                    _0x532b1f(_0x2df8c0, _0x16457e),
                    _0x532b1f(_0x3b4685, [_0x38b78d, _0x4b8fec, _0x5d1732, _0x2df8c0]);
                  if (_0x2026ae < 0x5) _0x532b1f(_0xed140c, _0x3b4685);
                  else _0x532b1f(_0x2f7f91, _0x3b4685);
                  _0x2d4778(_0x16457e, 0x1 + _0x3c9231[_0x1a0441(0x2c3)] / 0x64, _0x12e96b);
                });
            });
          })();
      }
      function _0x30f388() {
        const _0x599593 = _0x1ee7c4;
        let _0x203dcc = document[_0x599593(0x1ce)](_0x599593(0x1f3));
        if (!_0x203dcc) return;
        let _0x287f86 = (_0x203dcc[_0x599593(0x21f)]('lcw-base') || _0x599593(0x2d1))[_0x599593(0x2cf)](),
          _0x2c489b = (_0x203dcc[_0x599593(0x21f)](_0x599593(0x2bb)) || 'd')[_0x599593(0x2cf)](),
          _0x227f77 = _0x203dcc['getAttribute']('lcw-color-tx') || '#000000',
          _0xbdf6c = _0x203dcc[_0x599593(0x21f)](_0x599593(0x1c6)) || _0x599593(0x275),
          _0xc8c59f = _0x203dcc[_0x599593(0x21f)](_0x599593(0x209)) || _0x599593(0x262),
          _0x29d513 = !![],
          _0x3ef3e2 = _0x1667c6(_0x2c489b),
          _0x5cc9fc = _0x5e6894 + (_0x29d513 ? ';' + _0x3addd7 : ''),
          _0x539dea = _0x29d513 ? _0x3bb012 : '',
          _0x2d731a = _0x29d513 ? _0x462ed6 : _0x3df279,
          _0x53bfe3 = _0x29d513 ? _0x3b9afd : _0x3b5447,
          _0xe7e84a = _0x58b7e4(_0x599593(0x2b6), _0x1b34b2),
          _0x55a443 = _0x58b7e4(_0x599593(0x2b6), _0x46fe34),
          _0x13f6de = _0x58b7e4('div', _0x3f8418),
          _0x5637a0 = _0x58b7e4('p', [_0x70ae7, _0x539dea, _0x238dd6], 'MARKET\x20CAP'),
          _0x20d587 = _0x58b7e4('p', [_0x70ae7, _0x539dea, _0x238dd6], _0x599593(0x21a)),
          _0x57ee93 = _0x58b7e4(_0x599593(0x2b6), _0xf3d3fc),
          _0x31dc40 = _0x58b7e4('p', [_0x2d1e35, _0x539dea, _0x238dd6], '-'),
          _0xd8f51d = _0x58b7e4('p', [_0x2d1e35, _0x539dea, _0x238dd6], '-'),
          _0x3a8c35 = _0x58b7e4(_0x599593(0x2b6), _0xf3d3fc),
          _0x1631f8 = _0x58b7e4('p', [_0x70ae7, _0x539dea, _0x238dd6, _0x599593(0x1d3)], '-'),
          _0x48163b = _0x58b7e4('p', [_0x70ae7, _0x539dea, _0x238dd6, _0x599593(0x1d3)], '-'),
          _0x18f8f3 = _0x58b7e4(_0x599593(0x2b6), _0x4066f8, _0x19641()),
          _0x125b9c = _0x58b7e4(_0x599593(0x2b6), _0x1e6775),
          _0x18ded0 = _0x58b7e4('a', [_0x47a1bc, _0x3b5447, _0x599593(0x1b1) + _0xbdf6c]),
          _0x1fd340 = _0x58b7e4('p', [_0x70ae7, _0x2d731a, _0x4e43b5(0x5)], _0x41fdcb(_0x2c489b)),
          _0xe62f77 = _0x58b7e4('div', _0x428cee);
        (_0x203dcc['innerHTML'] = ''),
          _0x203dcc[_0x599593(0x26d)](_0x599593(0x277), _0x5cc9fc),
          (_0x18ded0['href'] = _0x599593(0x2db)),
          (_0x18ded0[_0x599593(0x22b)] = _0x599593(0x20d)),
          _0x532b1f(_0x13f6de, [_0x5637a0, _0x20d587]),
          _0x532b1f(_0x57ee93, [_0x31dc40, _0xd8f51d]),
          _0x532b1f(_0x3a8c35, [_0x1631f8, _0x48163b]),
          _0x532b1f(_0x18f8f3, _0x18ded0),
          _0x532b1f(_0x125b9c, _0x1fd340),
          _0x532b1f(_0xe7e84a, [_0x13f6de, _0x3a8c35, _0x57ee93]),
          _0x532b1f(_0x55a443, [_0x18f8f3, _0x125b9c]),
          _0x532b1f(_0x203dcc, [_0xe7e84a, _0xe62f77, _0x55a443]),
          (function _0x1246c6() {
            _0x3c4517(_0x3ef3e2, function (_0x4f1eba) {
              const _0x3d154b = _0x4f2a;
              if (!_0x4f1eba || _0x4f1eba[_0x3d154b(0x2e3)]['length'] === 0x0) return;
              setTimeout(_0x1246c6, _0x16d485);
              let _0x27c49d = _0x4f1eba[_0x3d154b(0x2e3)],
                _0x1f3b1f = _0x4f1eba[_0x3d154b(0x2dd)],
                _0x4a2ad4 = [],
                _0x15e970 = Number[_0x3d154b(0x283)],
                _0x358c8b = 0x0;
              (_0x31dc40['innerHTML'] = _0x2bd63f(_0x38b121(_0x1f3b1f['capNow']), _0x287f86)),
                (_0xd8f51d['innerHTML'] = _0x2bd63f(_0x38b121(_0x1f3b1f[_0x3d154b(0x201)]), _0x287f86)),
                _0x2d4778(
                  _0x1631f8,
                  0x1 + (_0x1f3b1f[_0x3d154b(0x31d)] - _0x27c49d[_0x27c49d['length'] - 0x2]['cap']) / _0x1f3b1f['capNow'],
                  _0x29d513,
                ),
                _0x2d4778(
                  _0x48163b,
                  0x1 +
                    (_0x1f3b1f[_0x3d154b(0x201)] - _0x27c49d[_0x27c49d[_0x3d154b(0x28d)] - 0x2]['volume']) /
                      _0x1f3b1f[_0x3d154b(0x201)],
                  _0x29d513,
                );
              let _0x3c7392 = new Date(new Date()[_0x3d154b(0x214)]() - (_0x48eb4e[_0x2c489b] || _0x48eb4e[0x0])['t']);
              (_0x27c49d = _0x27c49d['filter'](function (_0x141614) {
                const _0x51995f = _0x3d154b;
                return new Date(_0x141614[_0x51995f(0x301)])[_0x51995f(0x214)]() > _0x3c7392[_0x51995f(0x214)]();
              })),
                _0x27c49d[_0x3d154b(0x308)](function (_0x291e7c, _0x39d275) {
                  const _0xb7edf = _0x3d154b;
                  if (_0x291e7c['cap'] > _0x358c8b) _0x358c8b = _0x291e7c[_0xb7edf(0x33c)];
                  if (_0x291e7c[_0xb7edf(0x33c)] < _0x15e970) _0x15e970 = _0x291e7c[_0xb7edf(0x33c)];
                }),
                _0x27c49d[_0x3d154b(0x308)](function (_0x85b2ec, _0x404e48) {
                  const _0x686ca7 = _0x3d154b;
                  let _0x4b93f8 = _0x358c8b - _0x15e970;
                  _0x4a2ad4[_0x686ca7(0x2e7)]({
                    x: (_0x404e48 / _0x27c49d[_0x686ca7(0x28d)]) * 0x181,
                    y: 0x5f - Math[_0x686ca7(0x20a)](((_0x85b2ec[_0x686ca7(0x33c)] - _0x15e970) / _0x4b93f8) * 0x5a),
                    cap: _0x85b2ec[_0x686ca7(0x33c)],
                    date: _0x85b2ec[_0x686ca7(0x301)],
                  });
                });
              let _0x2d9b35 = _0x4a2ad4[_0x3d154b(0x1f0)](function (_0x4c46f2) {
                return _0x4c46f2['x'] + ',' + (isNaN(_0x4c46f2['y']) ? 0x0 : _0x4c46f2['y']);
              })[_0x3d154b(0x330)]('\x20');
              _0x2d9b35 +=
                _0x3d154b(0x343) +
                _0x4a2ad4[_0x4a2ad4[_0x3d154b(0x28d)] - 0x1]['y'] +
                _0x3d154b(0x1c5) +
                _0x4a2ad4[0x0]['y'];
              let _0x405934 = _0x29d513 ? '#283d4b' : _0x3d154b(0x1f4),
                _0x6b0320 = _0x298f44(_0x3d154b(0x25c), _0x3d154b(0x2ce), _0x3d154b(0x22d));
              _0x6b0320['setAttribute']('r', 0x0),
                (_0xe62f77['innerHTML'] =
                  _0x3d154b(0x348) +
                  '<polyline\x20style=\x22fill:' +
                  _0x405934 +
                  _0x3d154b(0x29c) +
                  _0x2d9b35 +
                  _0x3d154b(0x303) +
                  _0x3d154b(0x28f)),
                _0x532b1f(_0xe62f77[_0x3d154b(0x2ed)], _0x6b0320);
              let _0x4af922 = _0xe62f77['firstChild'][_0x3d154b(0x2f5)]();
              _0xe62f77[_0x3d154b(0x2ed)]['addEventListener'](_0x3d154b(0x300), function (_0x31b26c) {
                const _0x2fee03 = _0x3d154b;
                (_0x4af922['x'] = _0x31b26c['clientX']), (_0x4af922['y'] = _0x31b26c[_0x2fee03(0x229)]);
                let _0x25d062 = _0x4af922['matrixTransform'](
                  _0xe62f77[_0x2fee03(0x2ed)][_0x2fee03(0x2ac)]()[_0x2fee03(0x338)](),
                );
                _0x6b0320[_0x2fee03(0x26d)]('r', 0x5);
                let _0x68e930;
                for (let _0x4ad067 = 0x0; _0x4ad067 < _0x4a2ad4['length']; _0x4ad067++) {
                  if (_0x4a2ad4[_0x4ad067]['x'] > _0x25d062['x']) {
                    let _0x56d0a9 = _0x4a2ad4[Math[_0x2fee03(0x2d6)](_0x4ad067 - 0x1, 0x0)];
                    if (_0x25d062['x'] - _0x56d0a9 < _0x4a2ad4[_0x4ad067]['x'] - _0x25d062['x'])
                      _0x68e930 = _0x4a2ad4[_0x4ad067 - 0x1];
                    else _0x68e930 = _0x4a2ad4[_0x4ad067];
                    _0x6b0320[_0x2fee03(0x26d)]('cx', _0x68e930['x']), _0x6b0320[_0x2fee03(0x26d)]('cy', _0x68e930['y']);
                    break;
                  }
                }
                _0x1fd340[_0x2fee03(0x218)] =
                  _0x12a774(new Date(_0x68e930[_0x2fee03(0x301)])) +
                  '&nbsp;-&nbsp;' +
                  _0x38b121(_0x68e930[_0x2fee03(0x33c)]);
              }),
                _0xe62f77['firstChild'][_0x3d154b(0x2b7)](_0x3d154b(0x1c3), function (_0x2541ea) {
                  const _0x4b5e9e = _0x3d154b;
                  _0x6b0320[_0x4b5e9e(0x26d)]('r', 0x0),
                    (_0x1fd340['innerHTML'] = (_0x48eb4e[_0x2c489b] || _0x48eb4e[0x0])['l']);
                });
            });
          })();
      }
      function _0x5a1a5d() {
        const _0x223617 = _0x1ee7c4;
        let _0x20da78 = document[_0x223617(0x2de)](_0x223617(0x2bf));
        for (let _0x40e94d = 0x0; _0x40e94d < _0x20da78[_0x223617(0x28d)]; _0x40e94d++) {
          let _0x46100d = _0x20da78['item'](_0x40e94d);
          if (!_0x46100d) return;
          let _0x438e99 = (_0x46100d[_0x223617(0x21f)]('lcw-base') || _0x223617(0x2d1))[_0x223617(0x2cf)](),
            _0x3a7b4c = _0x46100d['getAttribute'](_0x223617(0x342)) || _0x223617(0x1ee),
            _0x44cf40 = _0x46100d['getAttribute'](_0x223617(0x1c6)) || _0x223617(0x275),
            _0x2b25b1 = _0x46100d[_0x223617(0x21f)](_0x223617(0x209)) || _0x223617(0x262),
            _0x26bbf0 = (_0x46100d[_0x223617(0x21f)](_0x223617(0x2be)) || '1') + 'px',
            _0x251a41 =
              (_0x46100d[_0x223617(0x21f)](_0x223617(0x25f)) || 'false')[_0x223617(0x2cf)]() === _0x223617(0x29b),
            _0x4d94ed = (_0x46100d['getAttribute'](_0x223617(0x20c)) || 'true')[_0x223617(0x2cf)]() === _0x223617(0x29b),
            _0x485910 =
              (_0x46100d[_0x223617(0x21f)](_0x223617(0x312)) || _0x223617(0x29b))[_0x223617(0x2cf)]() ===
              _0x223617(0x29b),
            _0x29e5ba =
              (_0x46100d[_0x223617(0x21f)](_0x223617(0x347)) || _0x223617(0x29b))[_0x223617(0x2cf)]() === 'true',
            _0x29b434 = !![];
          if (!_0x485910 && !_0x29e5ba) _0x4d94ed = !![];
          let _0x2abd48 = _0x4f06d1(0xa, _0x438e99),
            _0x1df931 = _0x558387(_0x438e99),
            _0x77d356 = _0x428a3c(_0x2b25b1, -0x14),
            _0x4b1065 = _0x10b99f([
              _0x43ec31,
              _0x223617(0x2c4) + _0x2b25b1,
              _0x223617(0x200) + _0x77d356,
              _0x223617(0x2ee) + _0x26bbf0,
            ]),
            _0x4ba6a0 = _0x10b99f([_0x3bb012, _0x223617(0x1b1) + _0x3a7b4c]),
            _0x29a8d1 = _0x10b99f([_0x462ed6, 'color:' + _0x3a7b4c + '64']),
            _0x1826d8 = _0x58b7e4(_0x223617(0x2b6), _0x251a41 ? _0x5c3294 : _0x5a4a65),
            _0x41c5cd = _0x58b7e4(_0x223617(0x2b6), [_0x1851ba]),
            _0x95adcc = _0x58b7e4(_0x223617(0x2b6), ''),
            _0x4035d4 = _0x58b7e4(_0x223617(0x2b6), [_0x238dd6, _0x1329ff, _0x223617(0x227)]),
            _0xd20e1e = _0x58b7e4('div', [_0x238dd6, _0x1329ff, _0x223617(0x227)]),
            _0x311b84 = _0x58b7e4('a', [_0x47a1bc, _0x3b5447, _0x223617(0x1b1) + _0x44cf40], _0x22c78e(_0x3a7b4c)),
            _0x381129 = _0x58b7e4(
              'p',
              [_0x70ae7, _0x29a8d1, _0x10155b, _0xedfccd(0x14), 'font-size:\x2010px'],
              _0x223617(0x226),
            ),
            _0x2a569a = _0x58b7e4(
              'p',
              [_0x70ae7, _0x29a8d1, _0x289187, _0x582041(0x14), _0x223617(0x2ff)],
              _0x223617(0x21a),
            ),
            _0x39e5a9 = _0x58b7e4('p', [_0x70ae7, _0x4ba6a0, _0x10155b, _0x5a4d16(0x2), _0xedfccd(0x14)], '-'),
            _0x450201 = _0x58b7e4('p', [_0x70ae7, _0x4ba6a0, _0x289187, _0x5a4d16(0x2), _0x582041(0x14)], '-');
          (_0x46100d[_0x223617(0x218)] = ''), _0x46100d[_0x223617(0x26d)](_0x223617(0x277), _0x4b1065);
          _0x251a41 &&
            (_0x532b1f(_0x4035d4, [_0x381129, _0x39e5a9]),
            _0x532b1f(_0xd20e1e, [_0x2a569a, _0x450201]),
            _0x532b1f(_0x41c5cd, [_0x4035d4, _0xd20e1e]));
          _0x532b1f(_0x1826d8, _0x311b84), _0x532b1f(_0x46100d, _0x1826d8);
          if (_0x251a41) _0x532b1f(_0x46100d, _0x41c5cd);
          _0x532b1f(_0x46100d, _0x95adcc),
            (_0x311b84['href'] = _0x223617(0x2db)),
            (_0x311b84[_0x223617(0x22b)] = _0x223617(0x20d));
          for (let _0x176d20 = 0x0; _0x176d20 < 0xa; _0x176d20++) {
            let _0x4ee23a = _0x58b7e4('div', [_0x10da04, _0x223617(0x278)]),
              _0x357d53 = _0x58b7e4(_0x223617(0x2b6), _0x223617(0x1b4)),
              _0xa2065e = _0x58b7e4(_0x223617(0x1bd), [_0x1ace2c, _0x5a4d16(0x8)]),
              _0x1a53e6 = _0x58b7e4(_0x223617(0x2b6), [
                _0x1329ff,
                _0x3899bc(0xa),
                _0x223617(0x2c5),
                _0x4343f,
                !_0x4d94ed || !_0x485910 ? _0x3ab5cd(0x5) : '',
              ]),
              _0x382a7e = _0x58b7e4('p', [_0x837592, _0x4ba6a0, !_0x485910 ? 'font-size:\x2013px' : '']),
              _0x103abf = _0x58b7e4('p', [_0x70ae7, _0x29a8d1, _0xca64a3, 'width:\x2080px']),
              _0x533d6a = _0x58b7e4(_0x223617(0x2b6), [
                _0x1329ff,
                _0x3899bc(0xa),
                'width:\x2045%;\x20text-align:\x20right',
              ]),
              _0x527b0c = _0x58b7e4('p', [_0x837592, _0x4ba6a0, _0x4343f, _0x3ab5cd(0x5)]),
              _0x2b517f = _0x58b7e4('div', [_0x1329ff, _0x3899bc(0x5)]),
              _0xf52c15 = _0x58b7e4('p', [_0x70ae7, _0x4ba6a0, _0x32bac3, _0x4343f, _0x3ab5cd(0x4)]);
            if (_0x4d94ed || _0x485910) _0x532b1f(_0x1a53e6, _0x382a7e);
            if (_0x4d94ed && _0x485910) _0x532b1f(_0x1a53e6, _0x103abf);
            _0x532b1f(_0x357d53, _0xa2065e),
              _0x532b1f(_0x533d6a, _0x527b0c),
              _0x532b1f(_0x2b517f, _0xf52c15),
              _0x532b1f(_0x4ee23a, [_0x357d53, _0x1a53e6, _0x533d6a, _0x2b517f]),
              _0x532b1f(_0x95adcc, _0x4ee23a);
          }
          function _0x50d732() {
            _0x3c4517(_0x2abd48, function (_0x1fe388) {
              const _0x57400b = _0x4f2a;
              if (!_0x1fe388 || !_0x1fe388[_0x57400b(0x25b)])
                return console[_0x57400b(0x1ca)](_0x57400b(0x235), _0x2abd48);
              let _0x45bf75 = _0x1fe388['data'];
              for (let _0x494d71 = 0x0; _0x494d71 < 0xa; _0x494d71++) {
                let _0x12e4d2 = _0x95adcc[_0x57400b(0x1b5)][_0x494d71],
                  _0x1402e9 = _0x12e4d2[_0x57400b(0x1b5)][0x2][_0x57400b(0x1b5)][0x0],
                  _0x284e37 = _0x12e4d2['children'][0x3][_0x57400b(0x1b5)][0x0],
                  _0x5c931b = _0x12e4d2[_0x57400b(0x1b5)][0x1];
                if (_0x4d94ed) {
                  let _0x1eca5c = _0x485910 ? _0x5c931b[_0x57400b(0x1b5)][0x1] : _0x5c931b[_0x57400b(0x1b5)][0x0];
                  _0x1eca5c[_0x57400b(0x218)] = _0x4d94ed
                    ? _0x45bf75[_0x494d71][_0x57400b(0x334)]
                    : _0x540c9a(_0x45bf75[_0x494d71][_0x57400b(0x2f1)]);
                }
                if (_0x485910) {
                  let _0x81aec2 = _0x5c931b[_0x57400b(0x1b5)][0x0];
                  _0x81aec2[_0x57400b(0x218)] = _0x540c9a(_0x45bf75[_0x494d71][_0x57400b(0x2f1)]);
                }
                if (_0x29e5ba) {
                  let _0x39d6b7 = _0x12e4d2['children'][0x0]['children'][0x0];
                  _0x39d6b7[_0x57400b(0x260)] = _0x4daa20(_0x45bf75[_0x494d71][_0x57400b(0x2f1)]);
                }
                (_0x1402e9[_0x57400b(0x218)] = _0x482f9f(_0x45bf75[_0x494d71][_0x57400b(0x329)], _0x438e99)),
                  _0x2d4778(_0x284e37, _0x45bf75[_0x494d71][_0x57400b(0x1f9)][_0x57400b(0x310)], _0x29b434);
              }
            });
          }
          function _0x58cab9() {
            _0x3c4517(_0x1df931, function (_0x3792ee) {
              const _0x50fb6e = _0x4f2a;
              if (!_0x3792ee || !_0x3792ee[_0x50fb6e(0x33c)] || !_0x3792ee['volume'])
                return console[_0x50fb6e(0x1ca)]('Invalid\x20totals\x20response!', _0x1df931);
              (_0x39e5a9[_0x50fb6e(0x218)] = _0x2bd63f(_0x38b121(_0x3792ee[_0x50fb6e(0x33c)]), _0x438e99)),
                (_0x450201[_0x50fb6e(0x218)] = _0x2bd63f(_0x38b121(_0x3792ee[_0x50fb6e(0x29e)]), _0x438e99));
            });
          }
          function _0x33545d() {
            _0x50d732(), _0x58cab9();
          }
          _0x33545d(), (_0x23257d = setInterval(_0x33545d, _0x16d485));
        }
      }
      function _0x3844ec() {
        const _0x2c9c37 = _0x1ee7c4;
        let _0x43c672 = document[_0x2c9c37(0x2de)](_0x2c9c37(0x32f));
        for (let _0x2dec4e = 0x0; _0x2dec4e < _0x43c672[_0x2c9c37(0x28d)]; _0x2dec4e++) {
          let _0x591067 = _0x43c672[_0x2c9c37(0x248)](_0x2dec4e);
          if (!_0x591067) return;
          let _0x53de07 = (_0x591067['getAttribute'](_0x2c9c37(0x23d)) || _0x2c9c37(0x1ec))['toLowerCase'](),
            _0x563e7 = (_0x591067['getAttribute'](_0x2c9c37(0x344)) || _0x2c9c37(0x2d1))[_0x2c9c37(0x2cf)](),
            _0xdfc695 = (_0x591067[_0x2c9c37(0x21f)](_0x2c9c37(0x291)) || _0x2c9c37(0x2d8))[_0x2c9c37(0x2cf)](),
            _0x1e75df = (_0x591067[_0x2c9c37(0x21f)](_0x2c9c37(0x2bb)) || 'd')[_0x2c9c37(0x2cf)](),
            _0x2fa112 = _0x591067[_0x2c9c37(0x21f)](_0x2c9c37(0x1e3)) || 'none',
            _0x33e79a = _0x591067[_0x2c9c37(0x21f)](_0x2c9c37(0x342)) || '#000000',
            _0x537d64 = _0x591067[_0x2c9c37(0x21f)](_0x2c9c37(0x1c6)) || '#58c7c5',
            _0x1ad3d4 = _0x591067['getAttribute'](_0x2c9c37(0x209)) || '#ffffff',
            _0x2a497e = (_0x591067['getAttribute'](_0x2c9c37(0x2be)) || '1') + 'px',
            _0x18877e = !![],
            _0x1f6988 = _0x4f4ae9(_0x53de07, _0x563e7, _0xdfc695),
            _0x5056fc = _0x3767d7(_0x53de07, _0x1e75df, _0x563e7),
            _0x4bd288 = _0x428a3c(_0x1ad3d4, -0x14),
            _0xffd3cf = _0x10b99f([
              _0x5e6894,
              _0x2c9c37(0x2c4) + _0x1ad3d4,
              'border-color:' + _0x4bd288,
              _0x2c9c37(0x2ee) + _0x2a497e,
            ]),
            _0x1aa14a = _0x10b99f([_0x3bb012, _0x2c9c37(0x1b1) + _0x33e79a]),
            _0x2a3cc3 = _0x10b99f([_0x462ed6, _0x2c9c37(0x1b1) + _0x33e79a + '64']),
            _0x2993a6 = _0x3b5447,
            _0x42129a = _0x58b7e4('div', _0x1b34b2),
            _0x28553a = _0x58b7e4(_0x2c9c37(0x2b6), _0x46fe34),
            _0x5b39c3 = _0x58b7e4(_0x2c9c37(0x1bd), _0x20cb07),
            _0x48173a = _0x58b7e4(_0x2c9c37(0x2b6), _0x3f8418),
            _0x37abcb = _0x58b7e4('p', [_0x70ae7, _0x2a3cc3, _0xca64a3, 'width:\x20100px'], '-'),
            _0x10f967 = _0x58b7e4('p', [_0x2d1e35, _0x1aa14a], '-'),
            _0x261b66 = _0x58b7e4('div', [_0xf3d3fc, _0x2c9c37(0x1d3)]),
            _0x2e091b = _0x58b7e4('p', [_0x2d1e35, _0x1aa14a], '-'),
            _0x11b66a = _0x58b7e4(_0x2c9c37(0x2b6), [_0xf3d3fc, _0x2c9c37(0x1d3)]),
            _0x33a59a = _0x58b7e4('p', [_0x70ae7, _0x1aa14a, _0x32bac3], '-'),
            _0x2caab5 = _0x58b7e4('p', [_0x70ae7, _0x1aa14a, _0x32bac3], '-'),
            _0x22faf2 = _0x58b7e4('p', [_0x70ae7, _0x2a3cc3]),
            _0x25df07 = _0x58b7e4(_0x2c9c37(0x2b6), _0x4066f8, _0x19641(_0x537d64)),
            _0x5bbdc4 = _0x58b7e4(_0x2c9c37(0x2b6), _0x1e6775),
            _0x2c4392 = _0x58b7e4(
              'a',
              [_0x47a1bc, _0x2993a6, _0x2c9c37(0x1b1) + _0x537d64],
              _0x540c9a(_0x53de07[_0x2c9c37(0x2ec)]()) + _0x2c9c37(0x272),
            ),
            _0x1891ca = _0x58b7e4(
              'p',
              [_0x17d6f7, _0x70ae7, _0x2a3cc3, _0x2c9c37(0x23f)],
              (_0x48eb4e[_0x1e75df] || _0x48eb4e[0x0])['l'],
            ),
            _0x37c893 = _0x58b7e4(_0x2c9c37(0x2b6), [_0x428cee, _0x563e7 === _0x53de07 ? _0x2c9c37(0x240) : '']);
          (_0x591067[_0x2c9c37(0x218)] = ''),
            _0x591067[_0x2c9c37(0x26d)]('style', _0xffd3cf),
            (_0x5b39c3['src'] = _0x4daa20(_0x53de07)),
            _0x532b1f(_0x48173a, [_0x10f967, _0x37abcb]),
            _0x532b1f(_0x261b66, [_0x2e091b, _0x22faf2]),
            _0x532b1f(_0x11b66a, [_0x33a59a, _0x2caab5]),
            _0x532b1f(_0x25df07, _0x2c4392),
            _0x532b1f(_0x5bbdc4, _0x1891ca),
            _0x532b1f(_0x42129a, [_0x5b39c3, _0x48173a, _0x11b66a, _0x261b66]),
            _0x532b1f(_0x28553a, [_0x25df07, _0x5bbdc4]),
            _0x532b1f(_0x591067, [_0x42129a, _0x37c893, _0x28553a]);
          function _0x4eb5c4() {
            _0x3c4517(_0x1f6988, function (_0x1c928b) {
              const _0x860170 = _0x4f2a;
              if (!_0x1c928b || !_0x1c928b[_0x860170(0x2ef)])
                return console[_0x860170(0x1ca)](_0x860170(0x221), _0x1f6988);
              let _0x57559b = _0x1c928b[_0x860170(0x25b)][_0x860170(0x333)](function (_0x6208cf) {
                  const _0x5478de = _0x860170;
                  return _0x6208cf['code'] === _0x53de07[_0x5478de(0x2ec)]();
                }),
                _0x22aca2 = _0x1c928b[_0x860170(0x25b)][_0x860170(0x333)](function (_0x5e4a06) {
                  const _0x1f2f6b = _0x860170;
                  return _0x5e4a06[_0x1f2f6b(0x2f1)] === _0xdfc695[_0x1f2f6b(0x2ec)]();
                });
              if (!_0x57559b || (_0xdfc695 && _0xdfc695 !== _0x860170(0x2d8) && !_0x22aca2)) return;
              (_0x37abcb['innerHTML'] = _0x57559b['name']),
                (_0x10f967[_0x860170(0x218)] = _0x540c9a(_0x57559b[_0x860170(0x2f1)])),
                (_0x2c4392[_0x860170(0x2aa)] = _0x518176(_0x57559b[_0x860170(0x334)], _0x57559b[_0x860170(0x2f1)])),
                (_0x2c4392[_0x860170(0x22b)] = '_blank'),
                (_0x2e091b[_0x860170(0x218)] = _0x482f9f(
                  _0x57559b[_0x860170(0x329)],
                  _0x1c928b[_0x860170(0x1e0)],
                  _0x2fa112,
                )),
                _0x2d4778(_0x33a59a, _0x3cbf82(_0x57559b[_0x860170(0x1f9)], _0x1e75df), _0x18877e);
              if (_0xdfc695 && _0xdfc695 !== _0x860170(0x2d8)) {
                let _0x34a324 = Number['isFinite'](Number[_0x860170(0x285)](_0x2fa112)) ? _0x2fa112 : 0x9;
                _0x22faf2[_0x860170(0x218)] = _0x482f9f(
                  _0x57559b[_0x860170(0x329)] / _0x22aca2['price'],
                  _0xdfc695,
                  Math['max'](_0x34a324, 0x9),
                );
                let _0x1bb7e3 = _0x57559b[_0x860170(0x329)] / _0x3cbf82(_0x57559b[_0x860170(0x1f9)], _0x1e75df),
                  _0x4e0181 = _0x22aca2['price'] / _0x3cbf82(_0x22aca2[_0x860170(0x1f9)], _0x1e75df);
                _0x2d4778(
                  _0x2caab5,
                  _0x57559b[_0x860170(0x329)] / _0x22aca2[_0x860170(0x329)] / (_0x1bb7e3 / _0x4e0181),
                  _0x18877e,
                );
              } else (_0x22faf2['innerHTML'] = ''), (_0x2caab5[_0x860170(0x218)] = '');
            });
          }
          _0x4eb5c4(), (_0x3f7434 = setInterval(_0x4eb5c4, _0x16d485));
          function _0x880fc2() {
            _0x3c4517(_0x5056fc, function (_0x2fb906) {
              const _0x3831e9 = _0x4f2a;
              if (!_0x2fb906 || !_0x2fb906[_0x3831e9(0x2ef)] || _0x2fb906[_0x3831e9(0x25b)][_0x3831e9(0x28d)] === 0x0)
                return;
              let _0x10f211 = _0x2fb906[_0x3831e9(0x25b)],
                _0x599154 = [],
                _0x561a06 = Number[_0x3831e9(0x283)],
                _0xcef369 = 0x0;
              _0x10f211['forEach'](function (_0xbf69e5, _0x5af2d8) {
                const _0x149124 = _0x3831e9;
                if (_0xbf69e5[_0x149124(0x1c9)] > _0xcef369) _0xcef369 = _0xbf69e5[_0x149124(0x1c9)];
                if (_0xbf69e5[_0x149124(0x1c9)] < _0x561a06) _0x561a06 = _0xbf69e5[_0x149124(0x1c9)];
              }),
                _0x10f211[_0x3831e9(0x308)](function (_0x5da026, _0x438556) {
                  const _0xe3a193 = _0x3831e9;
                  let _0x51dbaf = _0xcef369 - _0x561a06;
                  _0x599154[_0xe3a193(0x2e7)]({
                    x: (_0x438556 / _0x10f211[_0xe3a193(0x28d)]) * 0x181,
                    y: 0x5f - Math[_0xe3a193(0x20a)](((_0x5da026[_0xe3a193(0x1c9)] - _0x561a06) / _0x51dbaf) * 0x5a),
                    rate: _0x5da026[_0xe3a193(0x1c9)],
                    date: _0x5da026[_0xe3a193(0x301)],
                  });
                });
              let _0x348f26 = _0x599154[_0x3831e9(0x1f0)](function (_0x592dd1) {
                return _0x592dd1['x'] + ',' + (isNaN(_0x592dd1['y']) ? 0x0 : _0x592dd1['y']);
              })[_0x3831e9(0x330)]('\x20');
              _0x348f26 +=
                _0x3831e9(0x343) + _0x599154[_0x599154['length'] - 0x1]['y'] + _0x3831e9(0x1c5) + _0x599154[0x0]['y'];
              let _0x2eed12 = _0x537d64 + '25',
                _0x58cbd8 = _0x298f44(_0x3831e9(0x25c), _0x3831e9(0x2ce), _0x3831e9(0x2fb) + _0x537d64);
              _0x58cbd8[_0x3831e9(0x26d)]('r', 0x0),
                (_0x37c893[_0x3831e9(0x218)] =
                  '<svg\x20height=\x22150\x22\x20width=\x22380\x22>' +
                  '<polyline\x20style=\x22fill:' +
                  _0x2eed12 +
                  _0x3831e9(0x325) +
                  _0x537d64 +
                  _0x3831e9(0x1d2) +
                  _0x348f26 +
                  '\x22/>' +
                  _0x3831e9(0x28f)),
                _0x532b1f(_0x37c893[_0x3831e9(0x2ed)], _0x58cbd8);
              let _0x1608f3 = _0x37c893[_0x3831e9(0x2ed)][_0x3831e9(0x2f5)]();
              _0x37c893['firstChild'][_0x3831e9(0x2b7)](_0x3831e9(0x300), function (_0x5a1a36) {
                const _0x35e73c = _0x3831e9;
                (_0x1608f3['x'] = _0x5a1a36[_0x35e73c(0x311)]), (_0x1608f3['y'] = _0x5a1a36[_0x35e73c(0x229)]);
                let _0x187a21 = _0x1608f3[_0x35e73c(0x234)](_0x37c893[_0x35e73c(0x2ed)]['getScreenCTM']()['inverse']());
                _0x58cbd8[_0x35e73c(0x26d)]('r', 0x5);
                let _0x2e1f70;
                for (let _0x1a7c87 = 0x0; _0x1a7c87 < _0x599154[_0x35e73c(0x28d)]; _0x1a7c87++) {
                  if (_0x599154[_0x1a7c87]['x'] > _0x187a21['x']) {
                    let _0x5f2843 = _0x599154[Math[_0x35e73c(0x2d6)](_0x1a7c87 - 0x1, 0x0)];
                    if (_0x187a21['x'] - _0x5f2843 < _0x599154[_0x1a7c87]['x'] - _0x187a21['x'])
                      _0x2e1f70 = _0x599154[_0x1a7c87 - 0x1];
                    else _0x2e1f70 = _0x599154[_0x1a7c87];
                    _0x58cbd8[_0x35e73c(0x26d)]('cx', _0x2e1f70['x']), _0x58cbd8[_0x35e73c(0x26d)]('cy', _0x2e1f70['y']);
                    break;
                  }
                }
                _0x1891ca[_0x35e73c(0x218)] =
                  _0x4d430f(_0x2e1f70[_0x35e73c(0x301)]) + _0x35e73c(0x207) + _0x482f9f(_0x2e1f70['rate'], _0x563e7);
              }),
                _0x37c893['firstChild'][_0x3831e9(0x2b7)](_0x3831e9(0x1c3), function (_0x40b193) {
                  const _0x5bdfef = _0x3831e9;
                  _0x58cbd8['setAttribute']('r', 0x0),
                    (_0x1891ca[_0x5bdfef(0x218)] = (_0x48eb4e[_0x1e75df] || _0x48eb4e[0x0])['l']);
                });
            });
          }
          _0x880fc2(), (_0x2fa45c = setInterval(_0x880fc2, _0xc6122a));
        }
      }
      function _0x5ea7bd() {
        const _0x24d89c = _0x1ee7c4;
        let _0x511cf0 = document[_0x24d89c(0x2de)](_0x24d89c(0x254));
        for (let _0x420973 = 0x0; _0x420973 < _0x511cf0['length']; _0x420973++) {
          let _0x5f1da8 = _0x511cf0[_0x24d89c(0x248)](_0x420973);
          if (!_0x5f1da8) return;
          let _0x358626 = (_0x5f1da8[_0x24d89c(0x21f)](_0x24d89c(0x23d)) || _0x24d89c(0x1ec))['toLowerCase'](),
            _0x2e8fc1 = (_0x5f1da8[_0x24d89c(0x21f)](_0x24d89c(0x344)) || _0x24d89c(0x2d1))['toLowerCase'](),
            _0x3619a8 = (_0x5f1da8[_0x24d89c(0x21f)]('lcw-period') || 'd')[_0x24d89c(0x2cf)](),
            _0x4cdcd9 = _0x5f1da8[_0x24d89c(0x21f)]('lcw-color-tx') || _0x24d89c(0x1ee),
            _0xf237ca = _0x5f1da8[_0x24d89c(0x21f)](_0x24d89c(0x1c6)) || '#58c7c5',
            _0x114861 = _0x5f1da8['getAttribute']('lcw-color-bg') || _0x24d89c(0x262),
            _0x5db7ec = (_0x5f1da8[_0x24d89c(0x21f)](_0x24d89c(0x2be)) || '1') + 'px',
            _0x38d072 = !![],
            _0x4bef9f = _0x4f4ae9(_0x358626, _0x2e8fc1),
            _0x47ef14 = _0x428a3c(_0x114861, -0x14),
            _0x388e24 = _0x10b99f([
              _0x127d00,
              _0x24d89c(0x2c4) + _0x114861,
              'border-color:' + _0x47ef14,
              'border-width:' + _0x5db7ec,
            ]),
            _0x227af3 = _0x10b99f([_0x3bb012, _0x24d89c(0x1b1) + _0x4cdcd9]),
            _0x116460 = _0x10b99f([_0x462ed6, 'color:' + _0x4cdcd9 + '64']),
            _0x23daa6 = _0x3b5447,
            _0xe15cbc = '';
          if (_0x3619a8 === 'd') _0xe15cbc = _0x24d89c(0x257);
          else {
            if (_0x3619a8 === 'w') _0xe15cbc = '7d';
            else {
              if (_0x3619a8 === 'm') _0xe15cbc = _0x24d89c(0x1d9);
            }
          }
          let _0x53b541 = _0x58b7e4('a'),
            _0x25c7f3 = _0x58b7e4(_0x24d89c(0x2b6), [_0x24d89c(0x2fd), _0x24d89c(0x319), _0x24d89c(0x299)]),
            _0x2042fa = _0x58b7e4(_0x24d89c(0x1bd), _0x20cb07),
            _0x3d3667 = _0x58b7e4(_0x24d89c(0x2b6), _0x3f8418),
            _0x2965af = _0x58b7e4('p', [_0x70ae7, _0x116460, _0xca64a3, 'width:\x20100px'], '-'),
            _0x4f720e = _0x58b7e4('p', [_0x2d1e35, _0x227af3, _0x24d89c(0x1dc)], '-'),
            _0x51b42 = _0x58b7e4(_0x24d89c(0x2b6), [_0xf3d3fc, _0x24d89c(0x1d3), _0x24d89c(0x1dc)]),
            _0x1df5d0 = _0x58b7e4('p', [_0x2d1e35, _0x227af3], '-'),
            _0x46d1fc = _0x58b7e4(_0x24d89c(0x2b6)),
            _0x39b396 = _0x58b7e4(_0x24d89c(0x336), [_0x70ae7, _0x116460], '-'),
            _0x118706 = _0x58b7e4(_0x24d89c(0x336), [_0x70ae7, _0x116460, _0x24d89c(0x32a)], _0xe15cbc);
          (_0x5f1da8['innerHTML'] = ''),
            _0x5f1da8[_0x24d89c(0x26d)](_0x24d89c(0x277), _0x388e24),
            (_0x2042fa['src'] = _0x4daa20(_0x358626)),
            _0x532b1f(_0x3d3667, [_0x4f720e, _0x2965af]),
            _0x532b1f(_0x46d1fc, [_0x39b396, _0x118706]),
            _0x532b1f(_0x51b42, [_0x1df5d0, _0x46d1fc]),
            _0x532b1f(_0x25c7f3, [_0x2042fa, _0x3d3667, _0x51b42]),
            _0x532b1f(_0x53b541, [_0x25c7f3]),
            _0x532b1f(_0x5f1da8, [_0x53b541]);
          function _0x1f79b5() {
            _0x3c4517(_0x4bef9f, function (_0x5b77db) {
              const _0x1c2bba = _0x4f2a;
              if (!_0x5b77db || !_0x5b77db[_0x1c2bba(0x2ef)])
                return console['log']('Invalid\x20price\x20response!', _0x4bef9f);
              let _0x306602 = _0x5b77db[_0x1c2bba(0x25b)][_0x1c2bba(0x333)](function (_0x34d8e8) {
                const _0x311682 = _0x1c2bba;
                return _0x34d8e8[_0x311682(0x2f1)] === _0x358626[_0x311682(0x2ec)]();
              });
              if (!_0x306602) return;
              (_0x2965af[_0x1c2bba(0x218)] = _0x306602['name']),
                (_0x4f720e['innerHTML'] = _0x540c9a(_0x306602[_0x1c2bba(0x2f1)])),
                (_0x53b541[_0x1c2bba(0x2aa)] = _0x518176(_0x306602[_0x1c2bba(0x334)], _0x306602[_0x1c2bba(0x2f1)])),
                (_0x53b541[_0x1c2bba(0x22b)] = _0x1c2bba(0x20d)),
                (_0x1df5d0[_0x1c2bba(0x218)] = _0x482f9f(_0x306602[_0x1c2bba(0x329)], _0x5b77db[_0x1c2bba(0x1e0)])),
                _0x2d4778(_0x39b396, _0x3cbf82(_0x306602['delta'], _0x3619a8), _0x38d072);
            });
          }
          _0x1f79b5(), (_0x387bdd = setInterval(_0x1f79b5, _0x16d485));
        }
      }
      function _0x532b1f(_0x215757, _0x43bc22) {
        const _0x183746 = _0x1ee7c4;
        if (_0x43bc22['constructor'] === Array)
          _0x43bc22['forEach'](function (_0x1ded37) {
            _0x215757['appendChild'](_0x1ded37);
          });
        else _0x215757[_0x183746(0x288)](_0x43bc22);
      }
      function _0x58b7e4(_0x3d8f7c, _0x357979, _0x47b3a2) {
        const _0x55ab03 = _0x1ee7c4;
        let _0x11a3bf = document[_0x55ab03(0x293)](_0x3d8f7c);
        if (_0x357979)
          _0x11a3bf[_0x55ab03(0x26d)](
            _0x55ab03(0x277),
            _0xa556bd() + ';' + (_0x357979[_0x55ab03(0x2da)] === Array ? _0x357979[_0x55ab03(0x330)](';') : _0x357979),
          );
        if (_0x47b3a2) _0x11a3bf[_0x55ab03(0x218)] = _0x47b3a2;
        return _0x11a3bf;
      }
      function _0x298f44(_0x242995, _0x2e0079, _0x313670, _0xc2deea) {
        const _0xa828c9 = _0x1ee7c4;
        let _0x3c7f4a = document[_0xa828c9(0x267)](_0x242995, _0x2e0079);
        if (_0x313670) _0x3c7f4a[_0xa828c9(0x26d)](_0xa828c9(0x277), _0x313670);
        if (_0xc2deea) _0x3c7f4a[_0xa828c9(0x218)] = _0xc2deea;
        return _0x3c7f4a;
      }
      function _0x10b99f(_0x22d32f) {
        const _0x43ce05 = _0x1ee7c4;
        return _0x22d32f[_0x43ce05(0x330)](';');
      }
      function _0x4f4ae9(_0x154194, _0x47072c, _0x453e9c) {
        const _0x4744f1 = _0x1ee7c4;
        return (
          'https://http-api.livecoinwatch.com/widgets/coins?only=' +
          _0x154194[_0x4744f1(0x2ec)]() +
          (_0x453e9c && _0x453e9c !== _0x4744f1(0x2d8) ? ',' + _0x453e9c['toUpperCase']() : '') +
          '&currency=' +
          _0x47072c[_0x4744f1(0x2ec)]()
        );
      }
      function _0x1667c6(_0x5e7f32, _0x14fda0) {
        const _0x5ef301 = _0x1ee7c4;
        return _0x5ef301(0x210);
      }
      function _0x3767d7(_0x180b1a, _0x19907d, _0x42bfe5) {
        const _0x4650bb = _0x1ee7c4;
        let _0xa330a4 = (_0x48eb4e[_0x19907d] || _0x48eb4e[0x0])['t'],
          _0x4cc3d8 = new Date()[_0x4650bb(0x214)](),
          _0x2e6db5 = _0x4cc3d8 - _0xa330a4;
        return (
          'https://http-api.livecoinwatch.com/widgets/coins/history/range' +
          _0x4650bb(0x27d) +
          _0x180b1a[_0x4650bb(0x2ec)]() +
          _0x4650bb(0x335) +
          _0x25c716(_0x2e6db5) +
          _0x4650bb(0x345) +
          _0x25c716(_0x4cc3d8) +
          _0x4650bb(0x2ad) +
          _0x42bfe5['toUpperCase']() +
          '&points=' +
          0x3c
        );
      }
      function _0x4f06d1(_0x3dcd74, _0x41164e) {
        const _0x188ee5 = _0x1ee7c4;
        return _0x188ee5(0x2cc) + _0x188ee5(0x27f) + _0x3dcd74 + _0x188ee5(0x2ad) + _0x41164e[_0x188ee5(0x2ec)]();
      }
      function _0x558387(_0xffaaf0) {
        const _0xa6f1d2 = _0x1ee7c4;
        return _0xa6f1d2(0x2f8) + _0xa6f1d2(0x265) + _0xffaaf0[_0xa6f1d2(0x2ec)]();
      }
      function _0x1c6bfb(_0xbe47de, _0x287152) {
        const _0xa0a945 = _0x1ee7c4;
        return _0xa0a945(0x2b2) + _0xa0a945(0x27f) + _0xbe47de + _0xa0a945(0x2ad) + _0x287152['toUpperCase']();
      }
      function _0x4daa20(_0x42381e) {
        const _0x370856 = _0x1ee7c4;
        return _0x370856(0x2f4) + _0x42381e[_0x370856(0x2cf)]() + _0x370856(0x2d9);
      }
      function _0x518176(_0x311ca6, _0x411772) {
        const _0x3d81e8 = _0x1ee7c4;
        return _0x3d81e8(0x251) + _0x311ca6[_0x3d81e8(0x28b)](/\W/g, '') + '-' + _0x411772[_0x3d81e8(0x2ec)]();
      }
      function _0x3c4517(_0x1d7ad0, _0x23e686) {
        const _0x596048 = _0x1ee7c4;
        let _0x54164d = new XMLHttpRequest();
        (_0x54164d[_0x596048(0x2f7)] = function () {
          const _0x55a3f8 = _0x596048;
          _0x54164d[_0x55a3f8(0x339)] == XMLHttpRequest['DONE'] &&
            (_0x54164d['status'] == 0xc8
              ? _0x23e686(JSON[_0x55a3f8(0x30f)](_0x54164d[_0x55a3f8(0x20e)]))
              : _0x23e686(null));
        }),
          _0x54164d[_0x596048(0x222)](_0x596048(0x1d6), _0x1d7ad0, !![]),
          _0x54164d[_0x596048(0x30a)]();
      }
      function _0x3cbf82(_0x5980e6, _0x3b1c3b) {
        const _0x7ff839 = _0x1ee7c4;
        if (_0x3b1c3b === 'h') return _0x5980e6[_0x7ff839(0x24c)];
        if (_0x3b1c3b === 'w') return _0x5980e6[_0x7ff839(0x271)];
        if (_0x3b1c3b === 'm') return _0x5980e6[_0x7ff839(0x266)];
        return _0x5980e6['day'];
      }
      function _0x41fdcb(_0x38fb1f) {
        return (_0x48eb4e[_0x38fb1f] || _0x48eb4e[0x0])['l'];
      }
      function _0x1f57af(_0x2c527e) {
        return (_0x48eb4e[_0x2c527e] || _0x48eb4e[0x0])['t'];
      }
      function _0x25c716(_0x5496c0) {
        const _0x3c205e = _0x1ee7c4;
        return Math[_0x3c205e(0x20a)](_0x5496c0 / (0x5 * 0x3c * 0x3e8)) * (0x5 * 0x3c * 0x3e8);
      }
      function _0x482f9f(_0x3b129f, _0x28ffef, _0x587fd6) {
        const _0x24c8af = _0x1ee7c4;
        if (_0x587fd6 && Number['isFinite'](Number['parseInt'](_0x587fd6))) {
          let _0x594443 = ('' + _0x3b129f)[_0x24c8af(0x1b8)]('.')[0x0][_0x24c8af(0x28d)],
            _0x184d58 = Math[_0x24c8af(0x1be)](_0x587fd6, 0x9),
            _0x3af101 = Math[_0x24c8af(0x2d6)](_0x184d58 - _0x594443, 0x0);
          return _0x2bd63f(_0x3b129f['toFixed'](_0x3af101), _0x28ffef);
        }
        let _0x4b8684 = _0x3b129f < 0x1 ? _0x3b129f[_0x24c8af(0x1df)](0x5) : _0x3b129f[_0x24c8af(0x32b)](0x6);
        return _0x2bd63f(_0x4b8684, _0x28ffef);
      }
      function _0x36b9fd(_0x2bf7ad, _0x4aafcb, _0x169ad0, _0x25cb35) {
        const _0x5a5c51 = _0x1ee7c4;
        _0x2bf7ad[_0x5a5c51(0x218)] =
          (0x64 * (_0x4aafcb - 0x1))['toFixed'](Math[_0x5a5c51(0x244)](_0x4aafcb) >= 0x2 ? 0x0 : 0x1) + '%';
        let _0x1efe31 = _0x2bf7ad[_0x5a5c51(0x21f)]('style'),
          _0x2260f7 = _0x25cb35 ? _0x4a5eab : _0x53d79c,
          _0xa24fa7 = _0x25cb35 ? _0x24be26 : _0x4a5eab,
          _0x2a8b24 = _0x2bf7ad[_0x5a5c51(0x218)][_0x5a5c51(0x1bc)]('-') ? _0x2260f7 : _0xa24fa7;
        _0x2bf7ad['setAttribute']('style', _0x1efe31 + ';' + _0x5a5c51(0x2c2) + _0x2a8b24);
        if (_0x169ad0)
          _0x2bf7ad['innerHTML'] =
            (_0x2bf7ad[_0x5a5c51(0x218)][_0x5a5c51(0x1bc)]('-') ? 'â†“\x20' : 'â†‘\x20') +
            _0x2bf7ad['innerHTML'][_0x5a5c51(0x28b)]('-', '');
        else
          _0x2bf7ad[_0x5a5c51(0x218)] = (_0x2bf7ad['innerHTML']['startsWith']('-') ? '' : '+') + _0x2bf7ad['innerHTML'];
      }
      function _0x2d4778(_0x148e3b, _0xe285cd, _0x331737) {
        _0x36b9fd(_0x148e3b, _0xe285cd, ![], _0x331737);
      }
      function _0x38b121(_0x5ca2b7) {
        const _0x1f9582 = _0x1ee7c4,
          _0x21dd84 = 0x3b9aca00,
          _0x3c7077 = 0xf4240;
        if (_0x5ca2b7 >= _0x21dd84) return (_0x5ca2b7 / _0x21dd84)['toPrecision'](0x4) + '\x20B';
        if (_0x5ca2b7 >= _0x3c7077) return (_0x5ca2b7 / _0x3c7077)[_0x1f9582(0x32b)](0x4) + '\x20M';
        return (+_0x5ca2b7)[_0x1f9582(0x1df)](0x0)[_0x1f9582(0x28b)](/\B(?=(\d{3})+(?!\d))/g, ',');
      }
      function _0x4d430f(_0xa9786) {
        const _0x3799bf = _0x1ee7c4,
          _0x461d42 = [
            _0x3799bf(0x236),
            _0x3799bf(0x1f7),
            _0x3799bf(0x1cd),
            'Apr',
            _0x3799bf(0x2ca),
            _0x3799bf(0x2dc),
            _0x3799bf(0x2fa),
            'Aug',
            'Sep',
            _0x3799bf(0x1d7),
            _0x3799bf(0x2d3),
            _0x3799bf(0x22a),
          ],
          _0x21a055 = new Date(_0xa9786);
        return (
          _0x461d42[_0x21a055[_0x3799bf(0x2d5)]()] +
          '\x20' +
          _0x21a055[_0x3799bf(0x256)]() +
          ',\x20' +
          (_0x21a055[_0x3799bf(0x1e2)]() < 0xa ? '0' : '') +
          _0x21a055[_0x3799bf(0x1e2)]() +
          ':' +
          (_0x21a055[_0x3799bf(0x217)]() < 0xa ? '0' : '') +
          _0x21a055[_0x3799bf(0x217)]()
        );
      }
      function _0x12a774(_0xd8b2a8) {
        const _0x4021f3 = _0x1ee7c4,
          _0x4937dc = _0x4d430f(_0xd8b2a8)[_0x4021f3(0x1b8)]('\x20');
        return _0x4937dc[0x0] + '\x20' + _0x4937dc[0x1];
      }
      function _0x2bd63f(_0x2e6e82, _0x398189) {
        const _0x20cf90 = _0x1ee7c4;
        if (_0x445f41[_0x398189[_0x20cf90(0x2ec)]()]) return _0x445f41[_0x398189['toUpperCase']()] + '\x20' + _0x2e6e82;
        return _0x2e6e82 + '\x20' + _0x398189['toUpperCase']();
      }
      function _0x540c9a(_0x289f8d) {
        const _0x57729c = _0x1ee7c4;
        return _0x289f8d[_0x57729c(0x28b)](/^_*/, '');
      }
      function _0x428a3c(_0xf9a7ca, _0x3382bd) {
        const _0x56e36d = _0x1ee7c4;
        let _0x2c7f14 = parseInt(_0xf9a7ca[_0x56e36d(0x28b)](/^#/, ''), 0x10),
          _0x51fb42 = Math['round'](2.55 * _0x3382bd),
          _0x2408e6 = (_0x2c7f14 >> 0x10) + _0x51fb42,
          _0x3dff76 = ((_0x2c7f14 >> 0x8) & 0xff) + _0x51fb42,
          _0x12d43d = (_0x2c7f14 & 0xff) + _0x51fb42;
        return (
          '#' +
          (0x1000000 +
            (_0x2408e6 < 0xff ? (_0x2408e6 < 0x1 ? 0x0 : _0x2408e6) : 0xff) * 0x10000 +
            (_0x3dff76 < 0xff ? (_0x3dff76 < 0x1 ? 0x0 : _0x3dff76) : 0xff) * 0x100 +
            (_0x12d43d < 0xff ? (_0x12d43d < 0x1 ? 0x0 : _0x12d43d) : 0xff))
            [_0x56e36d(0x231)](0x10)
            [_0x56e36d(0x239)](0x1)
        );
      }
      function _0x11a54b(_0x5b05d2) {
        const _0x14a3c4 = _0x1ee7c4;
        return _0x14a3c4(0x323) + _0x5b05d2 + 'px';
      }
      function _0x5a4d16(_0x421798) {
        return 'padding-top:' + _0x421798 + 'px';
      }
      function _0x4e43b5(_0x34f47f) {
        const _0x59da7c = _0x1ee7c4;
        return _0x59da7c(0x2e9) + _0x34f47f + 'px';
      }
      function _0xdd9e53(_0x5e7bbc) {
        return 'padding-bottom:' + _0x5e7bbc + 'px';
      }
      function _0x3899bc(_0x37f958) {
        const _0x26f116 = _0x1ee7c4;
        return _0x26f116(0x252) + _0x37f958 + 'px';
      }
      function _0x2af5e8(_0x8346eb) {
        return 'margin:' + _0x8346eb + 'px';
      }
      function _0x2cd0c5(_0x4778c6) {
        const _0x312f98 = _0x1ee7c4;
        return _0x312f98(0x1dd) + _0x4778c6 + 'px';
      }
      function _0x582041(_0x1e7d77) {
        const _0x2e13d2 = _0x1ee7c4;
        return _0x2e13d2(0x27a) + _0x1e7d77 + 'px';
      }
      function _0x2ae20a(_0x41e63a) {
        const _0x19bc64 = _0x1ee7c4;
        return _0x19bc64(0x250) + _0x41e63a + 'px';
      }
      function _0xedfccd(_0x2e0f5e) {
        const _0x1bc33e = _0x1ee7c4;
        return _0x1bc33e(0x269) + _0x2e0f5e + 'px';
      }
      function _0x3ab5cd(_0xe788c7) {
        const _0xcc31c5 = _0x1ee7c4;
        return _0xcc31c5(0x326) + _0xe788c7 + 'px';
      }
      function _0xa58018(_0x591c29) {
        const _0x4df3a1 = _0x1ee7c4;
        return _0x4df3a1(0x203) + _0x591c29 + 'px';
      }
      function _0x3c3223(_0x4b59b0) {
        return 'width:\x20' + _0x4b59b0 + 'px';
      }
      function _0x30cf25(_0x593450) {
        return 'width:\x20' + _0x593450 + 'px';
      }
      function _0x57c93b(_0x4839e5) {
        return 'background-color:\x20' + _0x4839e5;
      }
      function _0x384a67(_0x27c570) {
        const _0x5c18d0 = _0x1ee7c4;
        return _0x5c18d0(0x32d) + _0x27c570 + _0x5c18d0(0x216);
      }
      function _0xd23550(_0x1eaa96) {
        return 'animation-delay:\x20-' + _0x1eaa96 + 's';
      }
      function _0xa556bd() {
        const _0x24f29e = _0x1ee7c4;
        return _0x10b99f([
          _0x24f29e(0x2bc),
          _0x24f29e(0x294),
          _0x24f29e(0x290),
          _0x24f29e(0x331),
          _0x24f29e(0x232),
          'animation-iteration-count\x20:\x201',
          _0x24f29e(0x30b),
          _0x24f29e(0x23b),
          _0x24f29e(0x28a),
          _0x24f29e(0x1e9),
          'background\x20:\x200',
          _0x24f29e(0x32e),
          _0x24f29e(0x1da),
          _0x24f29e(0x2bd),
          _0x24f29e(0x219),
          _0x24f29e(0x1eb),
          _0x24f29e(0x2a6),
          _0x24f29e(0x2af),
          _0x24f29e(0x2b5),
          _0x24f29e(0x213),
          _0x24f29e(0x1fe),
          _0x24f29e(0x1bb),
          'border-style\x20:\x20none',
          _0x24f29e(0x21e),
          _0x24f29e(0x258),
          _0x24f29e(0x2b0),
          _0x24f29e(0x306),
          _0x24f29e(0x2e0),
          'border-bottom-right-radius\x20:\x200',
          _0x24f29e(0x2f6),
          _0x24f29e(0x2fc),
          _0x24f29e(0x30d),
          'border-image\x20:\x20none',
          _0x24f29e(0x295),
          _0x24f29e(0x212),
          _0x24f29e(0x1ba),
          'border-left-width\x20:\x20medium',
          _0x24f29e(0x31e),
          _0x24f29e(0x320),
          _0x24f29e(0x1b9),
          _0x24f29e(0x280),
          _0x24f29e(0x33e),
          _0x24f29e(0x31b),
          _0x24f29e(0x273),
          _0x24f29e(0x322),
          _0x24f29e(0x1bf),
          'border-top-right-radius\x20:\x200',
          _0x24f29e(0x2a3),
          'border-top-width\x20:\x20medium',
          _0x24f29e(0x286),
          _0x24f29e(0x2f9),
          _0x24f29e(0x22e),
          _0x24f29e(0x1d8),
          'clear\x20:\x20none',
          _0x24f29e(0x1d1),
          'color\x20:\x20inherit',
          'columns\x20:\x20auto',
          _0x24f29e(0x2e5),
          'column-fill\x20:\x20balance',
          'column-gap\x20:\x20normal',
          _0x24f29e(0x2b3),
          _0x24f29e(0x2cd),
          'column-rule-style\x20:\x20none',
          _0x24f29e(0x1c2),
          _0x24f29e(0x20b),
          _0x24f29e(0x309),
          _0x24f29e(0x26f),
          'counter-increment\x20:\x20none',
          'counter-reset\x20:\x20none',
          _0x24f29e(0x1d4),
          _0x24f29e(0x26b),
          _0x24f29e(0x279),
          _0x24f29e(0x2cb),
          _0x24f29e(0x316),
          _0x24f29e(0x253),
          _0x24f29e(0x2a5),
          'font-style\x20:\x20normal',
          'font-variant\x20:\x20normal',
          _0x24f29e(0x2eb),
          _0x24f29e(0x241),
          _0x24f29e(0x27b),
          _0x24f29e(0x349),
          'letter-spacing\x20:\x20normal',
          _0x24f29e(0x2ba),
          _0x24f29e(0x30c),
          _0x24f29e(0x263),
          'list-style-position\x20:\x20outside',
          _0x24f29e(0x2c0),
          _0x24f29e(0x270),
          _0x24f29e(0x206),
          _0x24f29e(0x224),
          _0x24f29e(0x28e),
          'margin-top\x20:\x200',
          _0x24f29e(0x346),
          _0x24f29e(0x27e),
          _0x24f29e(0x21d),
          'min-width\x20:\x200',
          _0x24f29e(0x26e),
          'orphans\x20:\x200',
          _0x24f29e(0x29d),
          _0x24f29e(0x2c1),
          _0x24f29e(0x25d),
          _0x24f29e(0x261),
          _0x24f29e(0x2c6),
          _0x24f29e(0x284),
          _0x24f29e(0x23a),
          'padding\x20:\x200',
          _0x24f29e(0x1d0),
          _0x24f29e(0x21c),
          _0x24f29e(0x282),
          'padding-top\x20:\x200',
          _0x24f29e(0x341),
          _0x24f29e(0x24a),
          _0x24f29e(0x259),
          'perspective\x20:\x20none',
          _0x24f29e(0x215),
          _0x24f29e(0x1e1),
          _0x24f29e(0x228),
          _0x24f29e(0x25a),
          _0x24f29e(0x1c0),
          _0x24f29e(0x28c),
          'text-align-last\x20:\x20auto',
          _0x24f29e(0x2a9),
          _0x24f29e(0x237),
          _0x24f29e(0x1fd),
          'text-decoration-style\x20:\x20solid',
          _0x24f29e(0x211),
          'text-shadow\x20:\x20none',
          _0x24f29e(0x324),
          'top\x20:\x20auto',
          _0x24f29e(0x29f),
          _0x24f29e(0x31f),
          'transition\x20:\x20none',
          _0x24f29e(0x276),
          _0x24f29e(0x2a8),
          _0x24f29e(0x304),
          'transition-timing-function\x20:\x20ease',
          'unicode-bidi\x20:\x20normal',
          _0x24f29e(0x33d),
          _0x24f29e(0x287),
          _0x24f29e(0x1ad),
          'widows\x20:\x200',
          'width\x20:\x20auto',
          _0x24f29e(0x2b9),
          'z-index\x20:\x20auto',
        ]);
      }
      function _0x19641(_0x5a758c) {
        const _0xcbb5f8 = _0x1ee7c4;
        return (
          '<svg\x20width=32\x20height=20\x20viewBox=\x22\x22><path\x20fill-rule=\x22evenodd\x22\x20clip-rule=\x22evenodd\x22\x20fill=\x22' +
          _0x5a758c +
          _0xcbb5f8(0x1f6)
        );
      }
      function _0x22c78e(_0x200f56) {
        const _0x2ebb67 = _0x1ee7c4;
        return (
          ''+
          _0x2ebb67(0x245)
        );
      }
      _0x3844ec(), _0x30f388(), _0x5a1a5d(), _0x230020(), _0x1babf2(), _0x5ea7bd();
    })();